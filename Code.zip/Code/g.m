%%%%%%%%%%%%%%%%%%%%%% Main Code %%%%%%%%%%%%%%%%%%%%%%%%%%%
% A direct (but not rigorous) verification of Lemma 8 in the arXiv version of the paper
clear all
close all
warning('off')
delta=0.000002;
q =136/100;
eps=16/100;
maximum=-1000;
for rho=0.914:delta:0.9999
    rho2=rho+delta;
    p = 1 + (q - 1) * rho2^2;
    F= (eps + ((1 + rho2)/2)^p *(1 - 2*eps) )^(q/p) + (eps + ((1 - rho2)/2)^p * (1 - 2*eps))^(q/p);
    G= ((1 + rho)/2)^q   + ((1 - rho)/2)^q;
   
    f=F-G;
    if f>maximum
        maximum=f;
    end
end

if maximum<0 
    'Verification Successful'
end 



%%%%%%%%%%%%%%%%%%%%%% Main Code %%%%%%%%%%%%%%%%%%%%%%%%%%%
% A direct (but not rigorous) verification of Theorem 9 in the arXiv version of the paper
clear all
close all
global  omega 
omega=0.193027; 
delta=0.2;
maximum=-1000;
for rho=0.914:0.008:1
    f=xiq(rho);
    if f>-delta
        'Error'
    end
    if f>maximum
        maximum=f;
    end
end

if maximum-(-delta)<0 
    'Verification Successful'
end

%%%%%%%%%%%%%%%%%%%%%%%% Additional Code %%%%%%%%%%%%%%%%%%%%%%
% Define the functions used in Main Code
function [z] = xiq(rho)
global  omega  
syms s
t = vpasolve(-1/2 * (1+rho-4*omega*rho^2)*dphiq((1-s)/2)-phiq((1-rho)/2)==0, s, [0 1]);
z=(1+rho-4*omega*rho^2)*phiq((1-t)/2)-(1+t-rho^2)*phiq((1-rho)/2);
end

function [z] = phiq(t)
q=1.36;
z=(t^q+(1-t)^q-1)/(q-1)/t;
end

function [z] = dphiq(t)
q=1.36;
z=-((1+(q-1)*t)*(1-t)^(q-1)-1-(q-1)*t^q)/(q-1)/t^2;
end
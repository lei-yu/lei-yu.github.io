This file contains codes accompanying the paper Local Optimality of Dictator Functions with Applications to Courtade--Kumar and Li--Médard Conjectures by Lei Yu, arXiv:2410.10147.

The codes produce provably correct bounds by rounding off every number in the computation to finite effective digits, which is in fact equivalent to the idea of interval arithmetic.

Run CK_IntervalArithmetic.m to verify Theorem 7 in the arXiv version (i.e., Theorem 5.5 in the revised manuscript);
Run LM_IntervalArithmetic.m to verify Theorem 9 in the arXiv version;
Run g _IntervalArithmetic.m to verify Lemma 8 in the arXiv version.

In addition, we also provide the direct numerically computational versions for the verification above, which are respectively given in CK.m, LM.m, and g.m. Although these versions are not rigorous, but they are much clearer than the rigorous ones based on interval arithmetic and hence, might help readers understand our rigorous codes.
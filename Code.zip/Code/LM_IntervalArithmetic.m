%%%%%%%%%%%%%%%%%%%%%% Main Code %%%%%%%%%%%%%%%%%%%%%%%%%%%
% A rigorous verification of Theorem 9 in the arXiv version of the paper using interval arithmetic
clear all
close all
global  omega N
omega=0.193027; 
N=7; % Bound every number appearing in the computation into N effective digits;
     % 10^(-N) should be larger than the machine epsilon  2.2204e-16.
delta=0.2;
maximum=-1000;
for rho=0.914:0.008:1
    f=xiq(rho);
    if f>-delta
        'Error'
    end
    if f>maximum
        maximum=f;
    end
end
if maximum-(-delta)<0 
    'Verification Successful'
end

%%%%%%%%%%%%%%%%%%%%%%%% Additional Code %%%%%%%%%%%%%%%%%%%%%%
% Define the functions used in Main Code
function [z2] = xiq(rho)
global  omega
syms s
t = vpasolve(dxiq(rho,s,0)==0, s, [0 1]);
t=double(t);
t1=round1(t);
t2=round2(t);
if dxiq(rho,t1,1) * dxiq(rho,t2,2) >0 
    'Error 2'
end
x=phiq((1-t1)/2,2);
x2=round2(x);
y=phiq((1-rho)/2,1);
y1=round1(y);
z=(1+rho-4*omega*rho^2)*x2-(1+t2-rho^2)*y1;
z2=round2(z);
end


function [f2] = dxiq(rho,s,bound)
% If bound=0, then output an approximate of the function; 
% if bound=1, then output a lower bound of the function; 
% if bound=2, then output an upper bound of the function.
global  omega
if bound==0
    f2=-1/2 * (1+rho-4*omega*rho^2)*dphiq((1-s)/2,0)-phiq((1-rho)/2,0);
elseif bound==1
    x=dphiq((1-s)/2,2);
    x2=round2(x);
    y=phiq((1-rho)/2,2);
    y2=round2(y);
    f=-1/2 * (1+rho-4*omega*rho^2)*x2-y2;
    f2=round1(f);
elseif bound==2
    x=dphiq((1-s)/2,1);
    x1=round1(x);
    y=phiq((1-rho)/2,1);
    y1=round1(y);
    f=-1/2 * (1+rho-4*omega*rho^2)*x1-y1;
    f2=round2(f);
end
end


function [f2] = phiq(t,bound)
% If bound=0, then output an approximate of the function; 
% if bound=1, then output a lower bound of the function; 
% if bound=2, then output an upper bound of the function.
q=1.36;
x=t^q+(1-t)^q-1;
y=(q-1)*t;
if bound==0
    % f2=(t^q+(1-t)^q-1)/((q-1)*t);
    f2=x/y;
elseif bound==1    
    x2=round1(x);    
    y2=round1(y);
    f=x2/y2;
    f2=round1(f);
elseif bound==2
    x2=round2(x);
    y2=round2(y);
    f=x2/y2;
    f2=round2(f);
end
end


function [f2] = dphiq(t,bound)
% f2=(1+(q-1)*t^q-(1+(q-1)*t)*(1-t)^(q-1))/(q-1)/t^2;
% If bound=0, then output an approximate of the function; 
% if bound=1, then output a lower bound of the function; 
% if bound=2, then output an upper bound of the function.
q=1.36;
if bound==0
    f2=(1+(q-1)*t^q-(1+(q-1)*t)*(1-t)^(q-1))/(q-1)/t^2;
elseif bound==1
    x2=round1(round1(1+(q-1)*round1(t^q))-round2((1+(q-1)*t)*round2((1-t)^(q-1))));
    y2=round2((q-1)*t^2);
    f=x2/y2;
    f2=round1(f);
elseif bound==2
    x2=round2(round2(1+(q-1)*round2(t^q))-round1((1+(q-1)*t)*round1((1-t)^(q-1))));
    y2=round1((q-1)*t^2);
    f=x2/y2;
    f2=round2(f);
end
end


function [z] = round1(x)
%round off x to a smaller number
global N
y=round(x,N,"significant");
str = sprintf('%.0e', abs(y));
exp = str2double(str([3,4,5]));
z = y -10^(exp-(N-1));
end


function [z] = round2(x)
%round off x to a larger number
global N
y=round(x,N,"significant");
str = sprintf('%.0e', abs(y));
exp = str2double(str([3,4,5]));
z = y +10^(exp-(N-1));
end



%%%%%%%%%%%%%%%%%%%%%% Main Code %%%%%%%%%%%%%%%%%%%%%%%%%%%
% A rigorous verification of Lemma 8 in the arXiv version of the paper using interval arithmetic
clear all
close all
global N
N=8; % Bound every number appearing in the computation into N effective digits;
     % 10^(-N) should be larger than the machine epsilon  2.2204e-16.
delta=0.000002;
q =136/100;
eps=16/100;
maximum=-1000;
for rho=0.914:delta:0.9999
    rho2=rho+delta;
    p1 = round1(1 + (q - 1) * round1(rho2^2));
    p2 = round2(1 + (q - 1) * round2(rho2^2));
    F= round2(( round2(eps + round2(((1 + rho2)/2)^p1) *(1 - 2*eps)) )^(q/p2)) +round2(( round2(eps + round2(((1 - rho2)/2)^p1) *(1 - 2*eps)) )^(q/p2));
    G= round1(((1 + rho)/2)^q   + ((1 - rho)/2)^q);
   
    f=F-G;
    if f>maximum
        maximum=f;
    end
end
if maximum<0 
    'Verification Successful'
end 

%%%%%%%%%%%%%%%%%%%%%%%% Additional Code %%%%%%%%%%%%%%%%%%%%%%
% Define functions used in Main Code

function [z] = round1(x)
%round off x to a smaller number
global N
y=round(x,N,"significant");
str = sprintf('%.0e', abs(y));
exp = str2double(str([3,4,5]));
z = y -10^(exp-(N-1));
end


function [z] = round2(x)
%round off x to a larger number
global N
y=round(x,N,"significant");
str = sprintf('%.0e', abs(y));
exp = str2double(str([3,4,5]));
z = y +10^(exp-(N-1));
end


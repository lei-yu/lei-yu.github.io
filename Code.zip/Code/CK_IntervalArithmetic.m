%%%%%%%%%%%%%%%%%%%%%% Main Code %%%%%%%%%%%%%%%%%%%%%%%%%%%
% A rigorous verification of Theorem 5.5 in the revised paper 
% (i.e., Theorem 7 in the arXiv version of the paper) using interval arithmetic 
clear all
close all
global  omega N
omega=0.193027;
N=7; % Bound every number appearing in the computation into N effective digits;
     % 10^(-N) should be larger than the machine epsilon  2.2204e-16.
delta=0.0016;
maximum=-1000;
for rho=0.46:0.00008:0.914
    if mod(round(rho/0.00008),1000)==0
        rho
    end
    f=xi(rho);
    if f>-delta
        'Error'
    end
    if f>maximum
        maximum=f;
    end
end

if maximum-(-delta)<0 
    'Verification Successful'
end
    
%%%%%%%%%%%%%%%%%%%%%%%% Additional Code %%%%%%%%%%%%%%%%%%%%%%
% Define the functions used in Main Code
function [z2] = xi(rho)
global  omega
syms s
t = vpasolve(dxi(rho,s,0)==0, s, [0 1]);
t=double(t);
t1=round1(t);
t2=round2(t);
if dxi(rho,t1,1) * dxi(rho,t2,2) >0 
    'Error 2'
end
x=phi((1-t1)/2,2);
x2=round2(x);
y=phi((1-rho)/2,1);
y1=round1(y);
z=(1+rho-4*omega*rho^2)*x2-(1+t2-rho^2)*y1;
z2=round2(z);
end


function [f2] = dxi(rho,s,bound)
% If bound=0, then output an approximate of the function; 
% if bound=1, then output a lower bound of the function; 
% if bound=2, then output an upper bound of the function.
global  omega
if bound==0
    f2=-1/2 * (1+rho-4*omega*rho^2)*dphi((1-s)/2,0)-phi((1-rho)/2,0);
elseif bound==1
    x=dphi((1-s)/2,2);
    x2=round2(x);
    y=phi((1-rho)/2,2);
    y2=round2(y);
    f=-1/2 * (1+rho-4*omega*rho^2)*x2-y2;
    f2=round1(f);
elseif bound==2
    x=dphi((1-s)/2,1);
    x1=round1(x);
    y=phi((1-rho)/2,1);
    y1=round1(y);
    f=-1/2 * (1+rho-4*omega*rho^2)*x1-y1;
    f2=round2(f);
end
end


function [f2] = phi(t,bound)
% If bound=0, then output an approximate of the function; 
% if bound=1, then output a lower bound of the function; 
% if bound=2, then output an upper bound of the function.
x=log(t);
y=log(1-t);
z=1/t-1;
if bound==0
    % f=(t*log(t)+(1-t)*log(1-t))/t;
    f2=x+z*y;
elseif bound==1    
    x2=round1(x);    
    y2=round1(y);    
    z2=round2(z);
    f=x2+z2*y2;
    f2=round1(f);
elseif bound==2
    x2=round2(x);
    y2=round2(y);
    z2=round1(z);
    f=x2+z2*y2;
    f2=round2(f);
end
end


function [f2] = dphi(t,bound)
% If bound=0, then output an approximate of the function; 
% if bound=1, then output a lower bound of the function; 
% if bound=2, then output an upper bound of the function.
    x=-log(1-t);
    y=t^2;
if bound==0
    % f=(t*log(t)+(1-t)*log(1-t))/t;
    f2=x/y;
elseif bound==1
    x2=round1(x);
    y2=round2(y);
    f=x2/y2;
    f2=round1(f);
elseif bound==2
    x2=round2(x);
    y2=round1(y);
    f=x2/y2;
    f2=round2(f);
end
end


function [z] = round1(x)
%round off x to a smaller number
global N
y=round(x,N,"significant");
str = sprintf('%.0e', abs(y));
exp = str2double(str([3,4,5]));
z = y -10^(exp-(N-1));
end


function [z] = round2(x)
%round off x to a larger number
global N
y=round(x,N,"significant");
str = sprintf('%.0e', abs(y));
exp = str2double(str([3,4,5]));
z = y +10^(exp-(N-1));
end
%%%%%%%%%%%%%%%%%%%%%% Main Code %%%%%%%%%%%%%%%%%%%%%%%%%%%
% A direct (but not rigorous) verification of Theorem 5.5 in the revised
% paper (i.e., Theorem 7 in the arXiv version of the paper)
clear all
close all
global  omega  
omega=0.193027;
delta=0.0016;
maximum=-1000;
omega=0.15;
for rho=0.46:0.00008:1
    if mod(round(rho/0.00008),1000)==0
        rho
    end
    f=xi(rho);
    if f>-delta
        'Error'
    end
    if f>maximum
        maximum=f;
    end
end

if maximum-(-delta)<0 
    'Verification Successful'
end

%%%%%%%%%%%%%%%%%%%%%%%% Additional Code %%%%%%%%%%%%%%%%%%%%%%
% Define the functions used in Main Code

function [z] = xi(rho)
global  omega  
syms s
t = vpasolve(-1/2 * (1+rho-4*omega*rho^2)*dphi((1-s)/2)-phi((1-rho)/2)==0, s, [0 1]);
z=(1+rho-4*omega*rho^2)*phi((1-t)/2)-(1+t-rho^2)*phi((1-rho)/2);
end

function [z] = phi(t)
z=(t*log(t)+(1-t)*log(1-t))/t;
end

function [z] = dphi(t)
z=-log(1-t)/t^2;
end

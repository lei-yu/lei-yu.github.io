#!/usr/bin/env python3
"""Run all 20 independent exact profile/closure/three-bit base checks."""
import argparse,concurrent.futures,hashlib,json,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parent

def run_one(row,checks,skip):
    fp=ROOT/'results'/f'half_row_{row:02d}_{"_".join(checks)}.json'
    if skip and fp.exists():
        old=json.loads(fp.read_text())
        if old.get('status')=='CERTIFIED' and set(old.get('checks',[]))==set(checks):
            return {'row':row,'status':'CERTIFIED','source':'existing certificate receipt','seconds':old.get('elapsed_seconds')}
    cmd=[sys.executable,str(ROOT/'profile_base_exact.py'),'--row',str(row),'--checks',*checks]
    t=time.monotonic();result=subprocess.run(cmd,text=True,capture_output=True)
    good=result.returncode==0 and fp.exists() and json.loads(fp.read_text()).get('status')=='CERTIFIED'
    return {'row':row,'status':'CERTIFIED' if good else 'INCOMPLETE: NOT A CERTIFICATE','seconds':round(time.monotonic()-t,2),
        'stderr_tail':result.stderr[-400:] if result.stderr else ''}

def main():
    pa=argparse.ArgumentParser()
    pa.add_argument('--rows',nargs='+',type=int,default=list(range(1,21)))
    pa.add_argument('--checks',nargs='+',default=['positive','base','closure'],choices=['positive','base','closure'])
    pa.add_argument('--jobs',type=int,default=3)
    pa.add_argument('--skip-verified',action='store_true')
    args=pa.parse_args()
    assert all(1<=r<=20 for r in args.rows)
    res=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as ex:
        futures=[ex.submit(run_one,i,args.checks,args.skip_verified) for i in args.rows]
        for future in concurrent.futures.as_completed(futures):
            r=future.result();res.append(r)
            print('row',r['row'],r['status'],'seconds',r['seconds'],flush=True)
    res.sort(key=lambda x:x['row'])
    ledger={'status':'CERTIFIED' if all(r['status']=='CERTIFIED' for r in res) else 'INCOMPLETE',
            'checks':args.checks,'rows':res}
    out=ROOT/'results'/('profile_'+('_'.join(args.checks))+'_ledger.json')
    out.write_text(json.dumps(ledger,indent=2)+'\n')
    if ledger['status']!='CERTIFIED':sys.exit(1)

if __name__=='__main__':main()

#pragma once
#include "interval_generic.hpp"
namespace certified {
inline I meet(I a,I b){return I(std::max(a.lo,b.lo),std::min(a.hi,b.hi));}
inline J meet(const J&a,const J&b){J r(meet(a.v,b.v));for(unsigned j=0;j<3;++j)r.g[j]=meet(a.g[j],b.g[j]);return r;}
inline DD meet(const DD&a,const DD&b){DD r;for(unsigned j=0;j<7;++j)r.e[j]=meet(a.e[j],b.e[j]);return r;}
inline I entropy_coordinate_point(LD y){
 if(y==0||y==1)return I(0);
 I x(y),q=root(I(1)-power(x,ALPHA_N),ALPHA_N);
 return power(x,ALPHA_M)+power(q,ALPHA_M)-I(1);
}
inline I entropy_coordinate_range(I y){
 if(y.lo<0||y.hi>1)throw std::runtime_error("entropy coordinate outside [0,1]");
 I l=entropy_coordinate_point(y.lo),h=entropy_coordinate_point(y.hi);
 LD lower=std::max(0.0L,std::min(l.lo,h.lo)),upper=std::max(l.hi,h.hi);
 I mid=root(I::rat(1,2),ALPHA_N);
 if(y.lo<=mid.hi&&y.hi>=mid.lo)upper=std::max(upper,(I(2)*power(mid,ALPHA_M)-I(1)).hi);
 return I(lower,upper);
}
inline I tighten_entropy_coordinate(const I&y,const I&q,const I&z){
#ifdef DISABLE_ENTROPY_TIGHT
 return z;
#endif
 I out=meet(z,power(y,ALPHA_M)+power(q,ALPHA_M)-I(1));
 if(y.lo>=0&&y.hi<=1)out=meet(out,entropy_coordinate_range(y));
 return out;
}
inline J tighten_entropy_coordinate(const J&y,const J&q,const J&z){
#ifdef DISABLE_ENTROPY_TIGHT
 return z;
#endif
 J out=meet(z,power(y,ALPHA_M)+power(q,ALPHA_M)-J(1));
 if(y.v.lo>=0&&y.v.hi<=1)out.v=meet(out.v,entropy_coordinate_range(y.v));
 if(q.v.lo>0){
  I derivative=I(static_cast<int>(ALPHA_M))*power(y.v,ALPHA_M-1)-I(static_cast<int>(ALPHA_M))*power(y.v,ALPHA_N-1)/power(q.v,ALPHA_N-ALPHA_M);
  for(unsigned j=0;j<3;++j)out.g[j]=meet(out.g[j],derivative*y.g[j]);
 }
 return out;
}
inline DD tighten_entropy_coordinate(const DD&y,const DD&q,const DD&z){
#ifdef DISABLE_ENTROPY_TIGHT
 return z;
#endif
 DD out=meet(z,power(y,ALPHA_M)+power(q,ALPHA_M)-DD(1));
 for(unsigned j=0;j<3;++j)out.e[j]=tighten_entropy_coordinate(y.e[j],q.e[j],out.e[j]);
 return out;
}
}

#pragma once
#include "kernel_generic.hpp"

namespace certified {
// T0=q*K in the notation of endpoints_and_pair.tex.
inline J left_pair(const J&a,const J&b,const J&p){
 J q=J(1)-p,z0=J(1)-power(a,ALPHA_N);
 J w=root(power(a,ALPHA_N)+p*z0,ALPHA_N),t=root(J(1)-p*z0,ALPHA_N);
 DD rw=DD::variable({a,w,J(1)}),rt=DD::variable({a,t,J(1)});
 DD mw=endpoint(rw*DD(b))[1],mt=endpoint(rt*DD(b))[1];
 DD hw=power(rw,LEFT_POWER)*mw,ht=power(rt,LEFT_POWER)*mt;
 DD pw=power(rw,ALPHA_N),pt=power(rt,ALPHA_N);
 J first=hw.e[4]/pw.e[4],T0;
 if(a.v.hi<=I::rat(19,20).lo){
  T0=(ht.e[5]/pt.e[5]-hw.e[3]/pw.e[3])/(J(2)*z0);
 }else{
  auto fw=power_divdiff(hw,rw,ALPHA_N),ft=power_divdiff(ht,rt,ALPHA_N);
  T0=q*(fw.second+ft.second)/J(2);
 }
 J S0=J(phi())*(J(d0())-power(b,SHIFT)*mw.e[2])
     +J(I(1)-phi())*power(a,ALPHA_N)*(J(d0())-power(a*b,SHIFT)*mw.e[0]);
 return T0*(S0+J(eta())*p*power(b,SHIFT)*power(z0,2)*T0)
       -J(mu())*J(4)*(J(1)-p)*power(b,SHIFT)*power(first/J(d0()),2);
}

inline J right_pair(const J&a,const J&b,const J&p){
 J q=J(1)-p,z0=J(1)-power(a,ALPHA_N);
 J w=root(power(a,ALPHA_N)+p*z0,ALPHA_N),t=root(J(1)-p*z0,ALPHA_N);
 DD rw=DD::variable({a,w,J(1)}),rt=DD::variable({a,t,J(1)});
 DD hw=power(rw,ALPHA_M)*right_R(rw*DD(b));
 DD ht=power(rt,ALPHA_M)*right_R(rt*DD(b));
 DD pw=power(rw,ALPHA_N),pt=power(rt,ALPHA_N);
 J first=hw.e[4]/pw.e[4],T0;
 if(a.v.hi<=I::rat(19,20).lo){
  T0=(hw.e[3]/pw.e[3]-ht.e[5]/pt.e[5])/(J(2)*z0);
 }else{
  auto fw=power_divdiff(hw,rw,ALPHA_N),ft=power_divdiff(ht,rt,ALPHA_N);
  T0=-q*(fw.second+ft.second)/J(2);
 }
 J S0=J(phi())*hw.e[0]+J(I(1)-phi())*hw.e[2];
 J W0=power(b,SHIFT)+first/J(d0());
 return T0*(S0+J(eta())*p*power(z0,2)*T0)
       -J(mu())*J(4)*(J(1)-p)*power(W0,2);
}

inline J left_direct(const J&a,const J&b,const J&p){
 J z0=J(1)-power(a,ALPHA_N);
 J w=root(power(a,ALPHA_N)+p*z0,ALPHA_N),t=root(J(1)-p*z0,ALPHA_N);
 J ma=endpoint(a*b)[1],m1=endpoint(b)[1];
 J ha=power(a,LEFT_POWER)*ma,h1=m1;
 J hw=power(w,LEFT_POWER)*endpoint(w*b)[1],ht=power(t,LEFT_POWER)*endpoint(t*b)[1];
 J T0=(ha+h1-hw-ht)/(J(2)*p*power(z0,2));
 J S0=J(phi())*(J(d0())-power(b,SHIFT)*m1)
     +J(I(1)-phi())*power(a,ALPHA_N)*(J(d0())-power(a*b,SHIFT)*ma);
 J first=(h1-ha)/z0;
 return T0*(S0+J(eta())*p*power(b,SHIFT)*power(z0,2)*T0)
       -J(mu())*J(4)*(J(1)-p)*power(b,SHIFT)*power(first/J(d0()),2);
}

inline J right_direct(const J&a,const J&b,const J&p){
 J z0=J(1)-power(a,ALPHA_N);
 J w=root(power(a,ALPHA_N)+p*z0,ALPHA_N),t=root(J(1)-p*z0,ALPHA_N);
 J ha=power(a,ALPHA_M)*right_R(a*b),h1=right_R(b);
 J hw=power(w,ALPHA_M)*right_R(w*b),ht=power(t,ALPHA_M)*right_R(t*b);
 J T0=(hw+ht-ha-h1)/(J(2)*p*power(z0,2));
 J S0=J(phi())*ha+J(I(1)-phi())*h1;
 J W0=power(b,SHIFT)+(h1-ha)/(J(d0())*z0);
 return T0*(S0+J(eta())*p*power(z0,2)*T0)
       -J(mu())*J(4)*(J(1)-p)*power(W0,2);
}

inline I intersect(I a,I b){return I(std::max(a.lo,b.lo),std::min(a.hi,b.hi));}
inline J tighten(J out,const J&alternative){
 out.v=intersect(out.v,alternative.v);
 for(unsigned j=0;j<3;++j)out.g[j]=intersect(out.g[j],alternative.g[j]);
 return out;
}
inline J left_pair_tight(const J&a,const J&b,const J&p){
 J out=left_pair(a,b,p);
 if(a.v.hi<=I::rat(19,20).lo && a.v.lo<a.v.hi)out=tighten(out,left_direct(a,b,p));
 return out;
}
inline J right_pair_tight(const J&a,const J&b,const J&p){
 J out=right_pair(a,b,p);
 if(a.v.hi<=I::rat(19,20).lo && a.v.lo<a.v.hi)out=tighten(out,right_direct(a,b,p));
 return out;
}

template<class T>T cross_pair_generic(const T&l,const T&a,const T&p){
 T u=power(l,ALPHA_N),av=power(a,ALPHA_N),v=T(1)-av,z=v-u;
 T up=u+p*z,apv=av+p*z;
 T lp=root(up,ALPHA_N),ap=root(apv,ALPHA_N);
 auto el=endpoint_ar(l),ea=endpoint_ar(a),elp=endpoint_ar(lp),eap=endpoint_ar(ap);
 T gu=u*el[0],gv=power(a,ALPHA_M)*ea[1],gp=up*elp[0],gq=power(ap,ALPHA_M)*eap[1];
 T D=(gp+gq-gu-gv)/T(2),S=T(phi())*gv+T(I(1)-phi())*gu;
 T W=z-(gv-gu)/T(d0()),c=entropy_p(p);
 return D*(S+T(eta())*D)-T(mu())*T(4)*p*(T(1)-p)*power(W,2);
}
inline J cross_pair(const J&l,const J&a,const J&p){return cross_pair_generic(l,a,p);}

// Extract D/p using first divided differences before evaluating. This returns
// the original cross residual divided by the strictly positive noise p.
inline J cross_pair_fd(const J&l,const J&a,const J&p){
 J u=power(l,ALPHA_N),av=power(a,ALPHA_N),v=J(1)-av,z=v-u;
 J up=u+p*z,apv=av+p*z;
 J lp=root(up,ALPHA_N),ap=root(apv,ALPHA_N);
 FD fl=FD::variable(l,lp),fr=FD::variable(a,ap);
 auto el=endpoint_ar(fl),er=endpoint_ar(fr);
 FD pl=power(fl,ALPHA_N),pr=power(fr,ALPHA_N);
 J L=el[0].e[1]+u*el[0].e[2]/pl.e[2];
 FD hr=power(fr,ALPHA_M)*er[1];
 J R=hr.e[2]/pr.e[2],T=z*(L+R)/J(2);
 J gu=u*el[0].e[0],gv=hr.e[0];
 J S=J(phi())*gv+J(I(1)-phi())*gu,W=z-(gv-gu)/J(d0());
 return T*(S+J(eta())*p*T)-J(mu())*J(4)*(J(1)-p)*power(W,2);
}
inline J cross_pair_tight(const J&l,const J&a,const J&p){
 J fd=cross_pair_fd(l,a,p);
 try{return meet(fd,cross_pair(l,a,p)/p);}
 catch(const std::overflow_error&){return fd;}
}
}

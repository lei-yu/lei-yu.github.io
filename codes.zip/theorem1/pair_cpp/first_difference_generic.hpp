#pragma once
#include "interval_generic.hpp"
#include "entropy_generic.hpp"

namespace certified {
struct FD {
 std::array<J,3>e;
 FD():FD(J(0)){}
 FD(int x):FD(J(x)){}
 FD(I x):FD(J(x)){}
 FD(J x):e{x,x,J(0)}{}
 explicit FD(std::array<J,3>x):e(x){}
 static FD variable(const J&a,const J&b){return FD({a,b,J(1)});}
};
inline FD operator+(const FD&a,const FD&b){return FD({a.e[0]+b.e[0],a.e[1]+b.e[1],a.e[2]+b.e[2]});}
inline FD operator-(const FD&a){return FD({-a.e[0],-a.e[1],-a.e[2]});}
inline FD operator-(const FD&a,const FD&b){return a+(-b);}
inline FD operator*(const FD&a,const FD&b){return FD({a.e[0]*b.e[0],a.e[1]*b.e[1],a.e[0]*b.e[2]+a.e[2]*b.e[1]});}
inline FD reciprocal(const FD&a){J x=J(1)/a.e[0],y=J(1)/a.e[1];return FD({x,y,-a.e[2]*x*y});}
inline FD operator/(const FD&a,const FD&b){return a*reciprocal(b);}
inline FD power(const FD&a,unsigned n){
 if(n==0)return FD(1);if(n==1)return a;
 return FD({power(a.e[0],n),power(a.e[1],n),homogeneous<J>({a.e[0],a.e[1]},n-1)*a.e[2]});
}
inline FD root(const FD&a,unsigned n){
 if(n==1)return a;
 J x=root(a.e[0],n),y=root(a.e[1],n);
 return FD({x,y,a.e[2]/homogeneous<J>({x,y},n-1)});
}
inline FD tighten_entropy_coordinate(const FD&y,const FD&q,const FD&z){
 FD alt=power(y,ALPHA_M)+power(q,ALPHA_M)-FD(1),out;
 for(unsigned j=0;j<3;++j)out.e[j]=meet(z.e[j],alt.e[j]);
 out.e[0]=tighten_entropy_coordinate(y.e[0],q.e[0],out.e[0]);
 out.e[1]=tighten_entropy_coordinate(y.e[1],q.e[1],out.e[1]);
 return out;
}
}

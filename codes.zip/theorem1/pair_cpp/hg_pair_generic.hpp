#pragma once
#include "physical_generic.hpp"
#include "hermite_generic.hpp"
// Derivative tables from other alpha values must never be reused.
namespace certified {
inline J physical_pair_hg_unscaled(const J&u,const J&v,const J&z,const J&p,unsigned depth=99){
 if(!(p.v.lo>0&&p.v.hi<1&&u.v.lo>0&&v.v.hi<1))throw std::runtime_error("physical HG pair outside interior");
 J up=physical_mixture_node(u,v,p,z),vp=physical_mixture_node(u,v,J(1)-p,z);
 std::array<J,3> np={u,up,v},nq={u,vp,v};
 DD gp=physical_kernel(DD::variable(np)),gq=physical_kernel(DD::variable(nq));
 I hull(std::min(u.v.lo,v.v.lo),std::max(u.v.hi,v.v.hi));
 if(hull.lo>=I::rat(1,100).hi&&hull.hi<=I::rat(99,100).lo){
  S3 range=physical_kernel_series_hull(hull,depth==99?3:depth);
  gp=hermite_genocchi_meet(gp,np,range);gq=hermite_genocchi_meet(gq,nq,range);
 }
 J T0=-(J(1)-p)*(gp.e[6]+gq.e[6])/J(2);
 J S=J(phi())*gp.e[2]+J(I(1)-phi())*gp.e[0];
 J W0=J(1)-gp.e[4]/J(d0());
 return T0*(S+J(eta())*p*power(z,2)*T0)-J(mu())*J(4)*(J(1)-p)*power(W0,2);
}
inline J physical_right_hg(const J&a,const J&b,const J&p,unsigned depth=99){
 J bn=power(b,ALPHA_N),an=power(a,ALPHA_N),z=bn*(J(1)-an);
 return power(b,2*SHIFT)*physical_pair_hg_unscaled(J(1)-bn,J(1)-power(a*b,ALPHA_N),z,p,depth);
}
inline J physical_left_hg(const J&a,const J&b,const J&p,unsigned depth=99){
 J bn=power(b,ALPHA_N),an=power(a,ALPHA_N),z=bn*(J(1)-an);
 return physical_pair_hg_unscaled(power(a*b,ALPHA_N),bn,z,p,depth)/power(b,SHIFT);
}
inline J right_pair_hg_tight(const J&a,const J&b,const J&p){
 J out=right_pair_tight(a,b,p);
 if(physical_chart_applicable(a,b))try{return meet(out,physical_right_hg(a,b,p));}catch(const std::exception&){return out;}
 return out;
}
inline J left_pair_hg_tight(const J&a,const J&b,const J&p){
 J out=left_pair_tight(a,b,p);
 if(physical_chart_applicable(a,b))try{return meet(out,physical_left_hg(a,b,p));}catch(const std::exception&){return out;}
 return out;
}
}

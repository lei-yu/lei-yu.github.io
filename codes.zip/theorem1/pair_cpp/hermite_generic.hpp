#pragma once
#include "kernel_generic.hpp"
#include <vector>

// Independent univariate interval Taylor jets. c[k] encloses f^(k)(t)/k!
// for every t in the input interval, not a finite-difference approximation.
// This header does not alter any existing pair evaluator or running binary.
namespace certified {
struct S3 {
 std::array<I,4>c;
 S3():S3(I(0)){}
 S3(int x):S3(I(x)){}
 S3(I x):c{x,I(0),I(0),I(0)}{}
 explicit S3(std::array<I,4>x):c(x){}
 static S3 variable(I x){return S3({x,I(1),I(0),I(0)});}
};
inline S3 operator+(const S3&a,const S3&b){S3 r;for(unsigned k=0;k<4;++k)r.c[k]=a.c[k]+b.c[k];return r;}
inline S3 operator-(const S3&a){S3 r;for(unsigned k=0;k<4;++k)r.c[k]=-a.c[k];return r;}
inline S3 operator-(const S3&a,const S3&b){return a+(-b);}
inline S3 operator*(const S3&a,const S3&b){S3 r;for(unsigned k=0;k<4;++k)for(unsigned j=0;j<=k;++j)r.c[k]=r.c[k]+a.c[j]*b.c[k-j];return r;}
inline S3 reciprocal(const S3&a){
 S3 r;r.c[0]=I(1)/a.c[0];
 for(unsigned k=1;k<4;++k){I s(0);for(unsigned j=1;j<=k;++j)s=s+a.c[j]*r.c[k-j];r.c[k]=-s/a.c[0];}
 return r;
}
inline S3 operator/(const S3&a,const S3&b){return a*reciprocal(b);}
inline S3 power(const S3&a,unsigned n){
 if(n==0)return S3(1);if(n==1)return a;
 S3 r;r.c[0]=power(a.c[0],n);
 I d=I(static_cast<int>(n))*power(a.c[0],n-1);
 I d2=I::rat(static_cast<std::int64_t>(n)*(n-1),2)*power(a.c[0],n-2);
 r.c[1]=d*a.c[1];r.c[2]=d*a.c[2]+d2*power(a.c[1],2);
 r.c[3]=d*a.c[3]+I(2)*d2*a.c[1]*a.c[2];
 if(n>=3)r.c[3]=r.c[3]+I::rat(static_cast<std::int64_t>(n)*(n-1)*(n-2),6)*power(a.c[0],n-3)*power(a.c[1],3);
 return r;
}
inline S3 root(const S3&a,unsigned n){
 if(n==1)return a;if(n==0)throw std::runtime_error("zeroth series root");
 S3 r;r.c[0]=root(a.c[0],n);
 I d=I(static_cast<int>(n))*power(r.c[0],n-1);
 I d2=I::rat(static_cast<std::int64_t>(n)*(n-1),2)*power(r.c[0],n-2);
 r.c[1]=a.c[1]/d;
 r.c[2]=(a.c[2]-d2*power(r.c[1],2))/d;
 I rest=I(2)*d2*r.c[1]*r.c[2];
 if(n>=3)rest=rest+I::rat(static_cast<std::int64_t>(n)*(n-1)*(n-2),6)*power(r.c[0],n-3)*power(r.c[1],3);
 r.c[3]=(a.c[3]-rest)/d;
 return r;
}
inline I physical_entropy_point(LD t){
 if(t==0||t==1)return I(0);
 return power(root(I(t),ALPHA_N),ALPHA_M)+power(root(I(1)-I(t),ALPHA_N),ALPHA_M)-I(1);
}
inline I physical_entropy_range(I t){
 if(t.lo<0||t.hi>1)throw std::runtime_error("physical entropy outside [0,1]");
 I l=physical_entropy_point(t.lo),r=physical_entropy_point(t.hi);
 LD low=std::max(0.0L,std::min(l.lo,r.lo)),high=std::max(l.hi,r.hi);
 if(t.lo<=0.5L&&t.hi>=0.5L)high=std::max(high,(I(2)*power(root(I(0.5L),ALPHA_N),ALPHA_M)-I(1)).hi);
 return I(low,high);
}
inline S3 physical_kernel_series(I domain){
 if(!(domain.lo>0&&domain.hi<1))throw std::runtime_error("kernel Taylor jet requires interior interval");
 S3 t=S3::variable(domain);I q=I(1)-domain;
 I yt=root(domain,ALPHA_N),yq=root(q,ALPHA_N),yt9=power(yt,SHIFT),yq9=power(yq,SHIFT);
 // Closed entropy derivatives avoid cancellation through two nested roots.
 S3 f({physical_entropy_range(domain),
       I::rat(ALPHA_M,ALPHA_N)*(I(1)/yt9-I(1)/yq9),
       -I::rat(static_cast<std::int64_t>(ALPHA_M)*SHIFT,2*static_cast<std::int64_t>(ALPHA_N)*ALPHA_N)*(I(1)/(domain*yt9)+I(1)/(q*yq9)),
       I::rat(static_cast<std::int64_t>(ALPHA_M)*SHIFT*(2*ALPHA_N-ALPHA_M),6*static_cast<std::int64_t>(ALPHA_N)*ALPHA_N*ALPHA_N)*(I(1)/(power(domain,2)*yt9)-I(1)/(power(q,2)*yq9))});
 S3 x=power(root(f,ALPHA_M),SHIFT),nn=horner(Ncoeff(),f),pp=horner(Pcoeff(),f);
 nn.c[0]=polynomial_value_guard(f.c[0],nn.c[0],true);
 pp.c[0]=polynomial_value_guard(f.c[0],pp.c[0],false);
 return f*(S3(2)*t*pp+x*nn)/(pp+x*nn);
}
inline S3 physical_kernel_series_hull(I domain,unsigned depth=3){
 // Subdivision is purely enclosure refinement. The subintervals exactly
 // share floating-point boundaries; no sample or approximate value is used.
 std::vector<I> pending{domain};
 for(unsigned k=0;k<depth;++k){std::vector<I> next;for(I x:pending){LD m=(x.lo+x.hi)/2;if(m>x.lo&&m<x.hi){next.emplace_back(x.lo,m);next.emplace_back(m,x.hi);}else next.push_back(x);}pending.swap(next);}
 bool first=true;S3 result;
 for(I x:pending){S3 y=physical_kernel_series(x);if(first){result=y;first=false;}else for(unsigned j=0;j<4;++j)result.c[j]=I(std::min(result.c[j].lo,y.c[j].lo),std::max(result.c[j].hi,y.c[j].hi));}
 return result;
}
inline DD hermite_genocchi_meet(const DD&g,const std::array<J,3>&nodes,const S3&range){
 DD out=g;
 for(unsigned i=0;i<3;++i){
  out.e[i].v=meet(out.e[i].v,range.c[0]);
  for(unsigned j=0;j<3;++j)out.e[i].g[j]=meet(out.e[i].g[j],range.c[1]*nodes[i].g[j]);
 }
 const std::array<std::array<unsigned,3>,3> edges={{{0,1,3},{0,2,4},{1,2,5}}};
 for(auto edge:edges){unsigned i=edge[0],k=edge[1],slot=edge[2];
  out.e[slot].v=meet(out.e[slot].v,range.c[1]);
  for(unsigned j=0;j<3;++j){
   // Each simplex barycentric weight integrates to 1/2 independently.
   I derivative=range.c[2]*nodes[i].g[j]+range.c[2]*nodes[k].g[j];
   out.e[slot].g[j]=meet(out.e[slot].g[j],derivative);
  }
 }
 out.e[6].v=meet(out.e[6].v,range.c[2]);
 for(unsigned j=0;j<3;++j){
  // Each of the three barycentric weights integrates to 1/6. Do not
  // factor the coefficient around the sum: that would lose validity.
  I derivative(0);for(unsigned i=0;i<3;++i)derivative=derivative+range.c[3]*nodes[i].g[j];
  out.e[6].g[j]=meet(out.e[6].g[j],derivative);
 }
 return out;
}
inline DD hermite_genocchi_meet(const DD&g,const std::array<J,3>&nodes,unsigned depth=3){
 I hull(std::min({nodes[0].v.lo,nodes[1].v.lo,nodes[2].v.lo}),std::max({nodes[0].v.hi,nodes[1].v.hi,nodes[2].v.hi}));
 if(hull.lo<I::rat(1,100).hi||hull.hi>I::rat(99,100).lo)return g;
 return hermite_genocchi_meet(g,nodes,physical_kernel_series_hull(hull,depth));
}
}

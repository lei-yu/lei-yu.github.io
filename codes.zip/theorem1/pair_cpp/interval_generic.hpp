#pragma once
#ifdef __FAST_MATH__
#error "Certified interval arithmetic must not be compiled with fast-math"
#endif
#ifdef __FAST_MATH__
#error "Certified interval arithmetic forbids fast-math"
#endif
#include <array>
#include <algorithm>
#include <cassert>
#include <cfloat>
#include <cfenv>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>
#include <vector>


// Enclosure arithmetic assumes IEEE round-to-nearest long double operations.
// Every nontrivial elementary arithmetic result is expanded by one ulp.
// powl proposes roots only; exact integer comparisons decide their endpoints.
namespace certified {
using LD=long double;

static_assert(LDBL_MANT_DIG==64,"This implementation requires 64-bit significands");
inline void initialize(){
 if(std::fegetround()!=FE_TONEAREST) throw std::runtime_error("FE_TONEAREST required");
}
inline LD down(LD x){if(!std::isfinite(x))throw std::overflow_error("nonfinite arithmetic");return std::nextafterl(x,-std::numeric_limits<LD>::infinity());}
inline LD up(LD x){if(!std::isfinite(x))throw std::overflow_error("nonfinite arithmetic");return std::nextafterl(x,std::numeric_limits<LD>::infinity());}
struct I {
 LD lo,hi;
 I():lo(0),hi(0){}
 I(int x):lo(x),hi(x){}
 explicit I(LD x):lo(x),hi(x){}
 I(LD l,LD h):lo(l),hi(h){if(!(l<=h))throw std::runtime_error("inverted interval");}
 static I rat(std::int64_t n,std::int64_t d){
  if(d<=0)throw std::runtime_error("nonpositive denominator");
  // All project coefficients fit exactly in a 64-bit-significand long double.
  LD x=static_cast<LD>(n)/static_cast<LD>(d);
  return n==0?I(0):I(down(x),up(x));
 }
 bool zero()const{return lo==0&&hi==0;}
 LD absmax()const{return std::max(std::fabs(lo),std::fabs(hi));}
};
inline I operator+(I a,I b){if(a.zero())return b;if(b.zero())return a;return I(down(a.lo+b.lo),up(a.hi+b.hi));}
inline I operator-(I a){return I(-a.hi,-a.lo);}
inline I operator-(I a,I b){return a+(-b);}
inline I operator*(I a,I b){
 if(a.zero()||b.zero())return I(0);
 std::array<LD,4> x={a.lo*b.lo,a.lo*b.hi,a.hi*b.lo,a.hi*b.hi};
 return I(down(*std::min_element(x.begin(),x.end())),up(*std::max_element(x.begin(),x.end())));
}
inline I operator/(I a,I b){
 if(b.hi<0)return (-a)/(-b);
 if(b.lo<=0)throw std::runtime_error("division contains zero");
 if(a.zero())return I(0);
 std::array<LD,4>x={a.lo/b.lo,a.lo/b.hi,a.hi/b.lo,a.hi/b.hi};
 return I(down(*std::min_element(x.begin(),x.end())),up(*std::max_element(x.begin(),x.end())));
}
inline I power(I a,unsigned n){
 if(n==0)return I(1);if(n==1)return a;
 if(a.zero())return I(0);
 auto endpoint=[](LD x,unsigned k){I r(1),b(x);while(k){if(k&1)r=r*b;k>>=1;if(k)b=b*b;}return r;};
 I l=endpoint(a.lo,n),h=endpoint(a.hi,n);
 if(n%2)return I(l.lo,h.hi);
 if(a.lo>=0)return I(l.lo,h.hi);
 if(a.hi<=0)return I(h.lo,l.hi);
 return I(0,std::max(l.hi,h.hi));
}
struct Dyadic {std::uint64_t mant;int exp;};
inline Dyadic dyadic(LD x){
 if(x==0)return {0,0};if(!(x>0&&std::isfinite(x)))throw std::runtime_error("positive finite dyadic required");
 int e;LD f=std::frexp(x,&e);LD m=std::ldexp(f,64);
 return {static_cast<std::uint64_t>(m),e-64};
}
// Exact nonnegative integers of at most 2048 bits. A 64-bit significand
// raised to n<=30 uses at most 1920 bits. Alignment after matching leading
// exponents never exceeds that width. Capacity checks are unconditional.
struct BigUInt {
 std::array<std::uint64_t,32>w{};unsigned len=0;
 explicit BigUInt(std::uint64_t x=0){if(x){w[0]=x;len=1;}}
 void multiply(std::uint64_t x){
  if(!x){w={};len=0;return;}
  __uint128_t carry=0;
  for(unsigned i=0;i<len;++i){__uint128_t z=static_cast<__uint128_t>(w[i])*x+carry;w[i]=static_cast<std::uint64_t>(z);carry=z>>64;}
  if(carry){if(len==w.size())throw std::overflow_error("BigUInt multiply capacity");w[len++]=static_cast<std::uint64_t>(carry);}
 }
 unsigned bits()const{return len?64*(len-1)+(64-__builtin_clzll(w[len-1])):0;}
 void shift(unsigned k){
  if(!len||!k)return;
  unsigned words=k/64,rem=k%64;
  if(len+words+(rem?1:0)>w.size())throw std::overflow_error("BigUInt shift capacity");
  BigUInt out;
  for(unsigned i=0;i<len;++i){out.w[i+words]|=w[i]<<rem;if(rem)out.w[i+words+1]|=w[i]>>(64-rem);}
  out.len=len+words+(rem?1:0);while(out.len&&out.w[out.len-1]==0)--out.len;*this=out;
 }
 int compare(const BigUInt&b)const{
  if(len!=b.len)return len<b.len?-1:1;
  for(unsigned i=len;i>0;--i)if(w[i-1]!=b.w[i-1])return w[i-1]<b.w[i-1]?-1:1;
  return 0;
 }
};
inline int compare_power(LD r,unsigned n,LD x){
 if(n==0||n>30)throw std::runtime_error("certified root degree outside 1..30");
 if(r==0)return x==0?0:-1;
 if(x==0)return 1;
 auto a=dyadic(r),b=dyadic(x);
 BigUInt lhs(1),rhs(b.mant);for(unsigned i=0;i<n;++i)lhs.multiply(a.mant);
 long le=static_cast<long>(a.exp)*n,re=b.exp;
 long lt=le+lhs.bits(),rt=re+rhs.bits();
 if(lt!=rt)return lt<rt?-1:1;
 if(le>=re)lhs.shift(static_cast<unsigned>(le-re));else rhs.shift(static_cast<unsigned>(re-le));
 return lhs.compare(rhs);
}
inline LD floor_root(LD x,unsigned n){
 if(x<0)throw std::runtime_error("negative root argument");if(x==0||n==1)return x;
 LD y=std::pow(x,1.0L/static_cast<LD>(n));
 if(!(y>0&&std::isfinite(y)))throw std::runtime_error("invalid root proposal");
 unsigned guard=0;
 while(compare_power(y,n,x)>0){y=std::nextafterl(y,0.0L);if(++guard>10000)throw std::runtime_error("root correction overflow");}
 while(true){LD z=std::nextafterl(y,std::numeric_limits<LD>::infinity());if(compare_power(z,n,x)>0)break;y=z;if(++guard>10000)throw std::runtime_error("root correction overflow");}
 return y;
}
inline I root(I x,unsigned n){
 if(x.lo<0)throw std::runtime_error("negative root enclosure");
 LD l=floor_root(x.lo,n),h=floor_root(x.hi,n);
 if(compare_power(h,n,x.hi)<0)h=std::nextafterl(h,std::numeric_limits<LD>::infinity());
 assert(compare_power(l,n,x.lo)<=0&&compare_power(h,n,x.hi)>=0);
 return I(l,h);
}
struct J {
 I v;std::array<I,3>g;
 J():v(0),g{I(0),I(0),I(0)}{}
 J(int x):v(x),g{I(0),I(0),I(0)}{}
 J(I x):v(x),g{I(0),I(0),I(0)}{}
 J(I x,std::array<I,3>gg):v(x),g(gg){}
 static J variable(I x,unsigned i){J r(x);r.g.at(i)=I(1);return r;}
};
inline J operator+(const J&a,const J&b){J r(a.v+b.v);for(unsigned i=0;i<3;++i)r.g[i]=a.g[i]+b.g[i];return r;}
inline J operator-(const J&a){J r(-a.v);for(unsigned i=0;i<3;++i)r.g[i]=-a.g[i];return r;}
inline J operator-(const J&a,const J&b){return a+(-b);}
inline J operator*(const J&a,const J&b){J r(a.v*b.v);for(unsigned i=0;i<3;++i)r.g[i]=a.g[i]*b.v+a.v*b.g[i];return r;}
inline J operator/(const J&a,const J&b){J r(a.v/b.v);for(unsigned i=0;i<3;++i)r.g[i]=(a.g[i]-r.v*b.g[i])/b.v;return r;}
inline J power(const J&a,unsigned n){if(n==0)return J(1);J r(power(a.v,n));I d=I(static_cast<int>(n))*power(a.v,n-1);for(unsigned i=0;i<3;++i)r.g[i]=d*a.g[i];return r;}
inline J root(const J&a,unsigned n){
 J r(root(a.v,n));bool zero=true;for(auto x:a.g)zero&=x.zero();if(zero)return r;
 I d=I(static_cast<int>(n))*power(r.v,n-1);for(unsigned i=0;i<3;++i)r.g[i]=a.g[i]/d;return r;
}
template<class T> T homogeneous(const std::vector<T>&xs,unsigned n){
 std::vector<T> h(n+1,T(0));h[0]=T(1);
 for(const T&x:xs)for(unsigned j=1;j<=n;++j)h[j]=h[j]+x*h[j-1];return h[n];
}
struct DD {
 std::array<J,7>e;
 DD():DD(J(0)){}
 DD(int x):DD(J(x)){}
 DD(I x):DD(J(x)){}
 DD(J x):e{x,x,x,J(0),J(0),J(0),J(0)}{}
 explicit DD(std::array<J,7>x):e(x){}
 static DD variable(std::array<J,3>r){return DD({r[0],r[1],r[2],J(1),J(1),J(1),J(0)});}
};
inline DD operator+(const DD&a,const DD&b){DD r;for(unsigned i=0;i<7;++i)r.e[i]=a.e[i]+b.e[i];return r;}
inline DD operator-(const DD&a){DD r;for(unsigned i=0;i<7;++i)r.e[i]=-a.e[i];return r;}
inline DD operator-(const DD&a,const DD&b){return a+(-b);}
inline DD operator*(const DD&aa,const DD&bb){
 auto&a=aa.e;auto&b=bb.e;
 return DD({a[0]*b[0],a[1]*b[1],a[2]*b[2],a[0]*b[3]+a[3]*b[1],a[0]*b[4]+a[4]*b[2],a[1]*b[5]+a[5]*b[2],a[0]*b[6]+a[3]*b[5]+a[6]*b[2]});
}
inline DD reciprocal(const DD&aa){
 const auto&a=aa.e;DD r;auto&b=r.e;
 for(unsigned i=0;i<3;++i)b[i]=J(1)/a[i];
 b[3]=-a[3]*b[0]*b[1];b[4]=-a[4]*b[0]*b[2];b[5]=-a[5]*b[1]*b[2];
 b[6]=-b[0]*(a[6]*b[2]+a[3]*b[5]);return r;
}
inline DD operator/(const DD&a,const DD&b){return a*reciprocal(b);}
inline DD power(const DD&aa,unsigned n){
 if(n==0)return DD(1);if(n==1)return aa;
 const auto&a=aa.e;DD r;auto&v=r.e;
 for(unsigned i=0;i<3;++i)v[i]=power(a[i],n);
 v[3]=homogeneous<J>({a[0],a[1]},n-1)*a[3];
 v[4]=homogeneous<J>({a[0],a[2]},n-1)*a[4];
 v[5]=homogeneous<J>({a[1],a[2]},n-1)*a[5];
 v[6]=homogeneous<J>({a[0],a[2]},n-1)*a[6]+homogeneous<J>({a[0],a[1],a[2]},n-2)*a[3]*a[5];return r;
}
inline DD root(const DD&aa,unsigned n){
 if(n==1)return aa;
 const auto&a=aa.e;DD rr;auto&r=rr.e;for(unsigned i=0;i<3;++i)r[i]=root(a[i],n);
 r[3]=a[3]/homogeneous<J>({r[0],r[1]},n-1);
 r[4]=a[4]/homogeneous<J>({r[0],r[2]},n-1);
 r[5]=a[5]/homogeneous<J>({r[1],r[2]},n-1);
 r[6]=(a[6]-homogeneous<J>({r[0],r[1],r[2]},n-2)*r[3]*r[5])/homogeneous<J>({r[0],r[2]},n-1);return rr;
}
template<class T> T horner(const std::vector<I>&co,const T&x){T z(co.back());for(int j=static_cast<int>(co.size())-2;j>=0;--j)z=z*x+T(co[j]);return z;}
template<class T> T geometric(const T&x,unsigned n){T s(1);for(unsigned j=1;j<n;++j)s=s*x+T(1);return s;}
inline std::pair<J,J> power_divdiff(const DD&h,const DD&r,unsigned exponent){DD p=power(r,exponent);J first=h.e[4]/p.e[4];J second=(h.e[6]-(h.e[3]/p.e[3])*p.e[6])/(p.e[4]*p.e[5]);return {first,second};}
}

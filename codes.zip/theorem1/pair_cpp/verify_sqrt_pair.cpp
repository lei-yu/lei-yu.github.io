#include "hg_pair_generic.hpp"
#include <iostream>
#include <iomanip>
#include <fstream>
#include <string>
#include <chrono>
#include <csignal>

using namespace certified;
struct Box{std::array<I,3>x;unsigned depth;};
// Independent full-domain runs only: partial checkpoints are diagnostic, not proof.
using Func=J(*)(const J&,const J&,const J&);
volatile std::sig_atomic_t stop_requested=0;
void request_stop(int){stop_requested=1;}
J eval(Func f,const Box&b){return f(J::variable(b.x[0],0),J::variable(b.x[1],1),J::variable(b.x[2],2));}
J eval_constant(Func f,const Box&b){return f(J(b.x[0]),J(b.x[1]),J(b.x[2]));}
void checkpoint(const std::string&path,const std::string&region,const std::vector<Box>&pending,std::uint64_t done,std::uint64_t accepted,LD minlower,const std::string&status){
 std::ofstream f(path);if(!f)throw std::runtime_error("cannot save checkpoint");
 f<<"{\"format\":\"exact binary80 hexadecimal endpoints\",\"band\":\""<<BAND_NAME<<"\",\"region\":\""<<region<<"\",\"evaluated\":"<<done<<",\"accepted\":"<<accepted<<",\"checkpoint_status\":\""<<status<<"\",\"observed_minimum_lower_hex\":";
 if(accepted)f<<"\""<<std::hexfloat<<minlower<<"\"";else f<<"null";
 f<<",\"boxes\":[";
 bool first=true;for(const auto&box:pending){if(!first)f<<",";first=false;f<<"{\"depth\":"<<box.depth<<",\"intervals\":[";
  for(unsigned j=0;j<3;++j){if(j)f<<",";f<<"[\""<<std::hexfloat<<box.x[j].lo<<"\",\""<<box.x[j].hi<<"\"]";}
  f<<"]}";
 }f<<"]}\n";
}
int main(int argc,char**argv){
 initialize();std::cout<<std::setprecision(std::numeric_limits<LD>::max_digits10);
 std::signal(SIGTERM,request_stop);std::signal(SIGINT,request_stop);
 std::string region=argc>1?argv[1]:"info";
 if(region=="info"){
  std::cout<<"{\"status\":\"compiled generic framework; no domain certification run\",\"band\":\""<<BAND_NAME<<"\",\"m\":"<<ALPHA_M<<",\"n\":"<<ALPHA_N<<",\"p_lower\":"<<p_lower().lo<<",\"p_upper\":"<<p_upper().hi<<",\"LDBL_MANT_DIG\":"<<LDBL_MANT_DIG<<",\"LDBL_MIN_EXP\":"<<LDBL_MIN_EXP<<",\"has_denorm\":"<<(std::numeric_limits<LD>::has_denorm==std::denorm_present?"true":"false")<<"}\n";return 0;
 }
 std::uint64_t max_boxes=argc>2?std::stoull(argv[2]):10000000ULL;
 std::string checkpoint_path=argc>3?argv[3]:std::string(BAND_NAME)+"_"+region+"_checkpoint.json";
 Func f;LD amax,bmax;
 if(region=="left"){f=left_pair_hg_tight;amax=1;bmax=I::rat(4,5).hi;}
 else if(region=="right"){f=right_pair_hg_tight;amax=1;bmax=I::rat(4,5).hi;}
 else if(region=="cross"){f=cross_pair_tight;amax=I::rat(3,5).hi;bmax=amax;}
 else throw std::runtime_error("unknown region");
 Box initial{{I(0.0L,amax),I(0.0L,bmax),I(p_lower().lo,p_upper().hi)},0};
 bool resumed=false;
 std::vector<Box>stack{initial};
 std::size_t initial_pending_count=stack.size();std::uint64_t done=0,accepted=0,exceptions=0,center_count=0;
 unsigned depthmax=0;LD minlower=std::numeric_limits<LD>::infinity();
 auto start=std::chrono::steady_clock::now();
 auto seconds=[&](){return std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();};
 while(!stack.empty()){
  if(stop_requested){
   checkpoint(checkpoint_path,region,stack,done,accepted,minlower,"INTERRUPTED: not a certificate");
   std::cout<<"{\"status\":\"INTERRUPTED: not a certificate\",\"band\":\""<<BAND_NAME<<"\",\"region\":\""<<region<<"\",\"evaluated\":"<<done<<",\"accepted\":"<<accepted<<",\"pending\":"<<stack.size()<<",\"checkpoint\":\""<<checkpoint_path<<"\",\"seconds\":"<<seconds()<<"}\n";return 1;
  }
  Box box=stack.back();stack.pop_back();++done;depthmax=std::max(depthmax,box.depth);
  LD lower=-std::numeric_limits<LD>::infinity();std::array<LD,3>scores{};bool gradient=false;
  try{
   J out=eval(f,box);lower=out.v.lo;
   if(lower<=0){
    Box point=box;I error(0);gradient=true;
    for(unsigned j=0;j<3;++j){
     // An enclosed derivative sign certifies the minimizing face.
     // Move to that face first; only the remaining axes need a Lipschitz
     // error. All derivative bounds were obtained on the original box.
     if(out.g[j].lo>=0){
      point.x[j]=I(box.x[j].lo);scores[j]=0;
     }else if(out.g[j].hi<=0){
      point.x[j]=I(box.x[j].hi);scores[j]=0;
     }else{
      LD middle=(box.x[j].lo+box.x[j].hi)/2;
      point.x[j]=I(middle);
      I radius=I(std::max((I(middle)-I(box.x[j].lo)).hi,(I(box.x[j].hi)-I(middle)).hi));
      I contribution=I(out.g[j].absmax())*radius;
      scores[j]=contribution.hi;error=error+contribution;
     }
    }
    J center=eval_constant(f,point);
    if(center.v.hi<0){
     checkpoint(checkpoint_path,region,std::vector<Box>{point},done,accepted,minlower,"NEGATIVE POINT: candidate rejected");
     std::cout<<"{\"status\":\"NEGATIVE POINT: candidate rejected\",\"band\":\""<<BAND_NAME<<"\",\"region\":\""<<region<<"\",\"evaluated\":"<<done<<",\"checkpoint\":\""<<checkpoint_path<<"\"}\n";return 2;
    }
    LD centered=(I(center.v.lo)-error).lo;
    if(centered>lower){lower=centered;if(lower>0)++center_count;}
   }
  }catch(const std::exception&){++exceptions;}
  if(lower>0){
   ++accepted;minlower=std::min(minlower,lower);
  }
  else{
   if(done>=max_boxes||box.depth>=75){
    stack.push_back(box);checkpoint(checkpoint_path,region,stack,done,accepted,minlower,"UNRESOLVED: not a certificate");
    std::cout<<"{\"status\":\"UNRESOLVED: not a certificate\",\"band\":\""<<BAND_NAME<<"\",\"region\":\""<<region<<"\",\"evaluated\":"<<done<<",\"accepted\":"<<accepted<<",\"pending\":"<<stack.size()<<",\"depth\":"<<box.depth<<",\"checkpoint\":\""<<checkpoint_path<<"\",\"seconds\":"<<seconds()<<"}\n";return 1;
   }
   unsigned axis=0;
   if(gradient){for(unsigned j=1;j<3;++j)if(scores[j]>scores[axis])axis=j;}
   else{
    for(unsigned j=0;j<3;++j)scores[j]=(box.x[j].hi-box.x[j].lo)/(initial.x[j].hi-initial.x[j].lo);
    for(unsigned j=1;j<3;++j)if(scores[j]>scores[axis])axis=j;
   }
   LD middle=(box.x[axis].lo+box.x[axis].hi)/2;
   if(!(middle>box.x[axis].lo&&middle<box.x[axis].hi))throw std::runtime_error("unsplittable box");
   Box left=box,right=box;++left.depth;++right.depth;left.x[axis].hi=middle;right.x[axis].lo=middle;
   stack.push_back(right);stack.push_back(left);
  }
  if(done%2000==0)std::cerr<<region<<" evaluated="<<done<<" accepted="<<accepted<<" pending="<<stack.size()<<" depth="<<depthmax<<" seconds="<<seconds()<<"\n";
 }
 std::cout<<"{\"status\":\""<<(resumed?"CERTIFIED: all resumed boxes strictly positive":"CERTIFIED: all boxes strictly positive")<<"\",\"resumed\":"<<(resumed?"true":"false")<<",\"initial_pending_count\":"<<initial_pending_count<<",\"band\":\""<<BAND_NAME<<"\",\"region\":\""<<region<<"\",\"evaluated\":"<<done<<",\"accepted\":"<<accepted<<",\"center_acceptances\":"<<center_count<<",\"domain_exceptions_subdivided\":"<<exceptions<<",\"maximum_depth\":"<<depthmax<<",\"minimum_lower\":"<<minlower<<",\"seconds\":"<<seconds()<<",\"arithmetic\":\"outward binary80 intervals; every root endpoint verified by exact integers\"}\n";
}

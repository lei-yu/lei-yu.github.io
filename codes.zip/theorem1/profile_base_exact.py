#!/usr/bin/env python3
"""Theorem 1: rigorous full-row profile/closure and three-bit base checks.

Proof obligations:
- polynomial B/(1-m^2)>0 on [-1,1] (nontrivial if needed);
- for all admissible m,x and noise in a given row, closure residual >=0,
  via two endpoints of the polynomial w=sqrt(1+s) as justified below;
- the bracket K>0 for use of endpoint reduction;
- all 15 nontrivial increasing three-bit base cases across noise interval.

B(0)=1, B(+/-1)=0, and interval adjacency are algebraic, not machine tests.
Every PASS is based solely on exact rational/Bernstein or integer-root bounds.
A FAIL or unresolved domain is never recorded as a certificate.
"""
import argparse,json,hashlib,math,sys,time
from pathlib import Path
from fractions import Fraction as Q
from math import comb,isqrt
from fixed_point_intervals import I,SCALE,sqrt_fraction
from generate_sqrt_pair import sq_floor, noise_interval
ROOT=Path(__file__).resolve().parent
DATA=json.loads((ROOT/'theorem1_rows.json').read_text())

# All coefficients are in rational arithmetic.
def pa(a,b):
    r=dict(a)
    for k,v in b.items():r[k]=r.get(k,Q(0))+v
    return {k:v for k,v in r.items() if v}
def ps(a,v):return {k:w*v for k,w in a.items() if w*v}
def pm(a,b):
    r={}
    for (i,j),v in a.items():
        for (k,l),w in b.items():r[i+k,j+l]=r.get((i+k,j+l),Q(0))+v*w
    return {k:v for k,v in r.items() if v}
def ii(v):
    a=Q(v);return I.rational(a.numerator,a.denominator)
def sqrtI(x):
    if x.lo<0:raise ArithmeticError('Square root contains a negative argument')
    u=isqrt(x.lo*SCALE);v=isqrt(x.hi*SCALE)
    if v*v<x.hi*SCALE:v+=1
    return I(u,v)
def horner(co,x):
    acc=ii(co[-1])
    for v in co[-2::-1]:acc=acc*x+ii(v)
    return acc

def sqrt_bound_interval(lo,hi):
    a=sq_floor(Q(lo))[0]
    b=sq_floor(Q(hi))[1]
    return a,b

def profile_coeff(row):
    D=Q(row['profile_denominator'])
    c=row['profile_c']
    T0={0:1};T1={1:1};Tk=[T0,T1]
    for k in range(2,len(c)+1):
        prev=Tk[-1];pp=Tk[-2]
        curr={}
        for j,v in prev.items():curr[j+1]=curr.get(j+1,0)+2*v
        for j,v in pp.items():curr[j]=curr.get(j,0)-v
        Tk.append({j:v for j,v in curr.items() if v})
    P={0:Q(1)}
    for j,cj in enumerate(c,1):
        if cj==0:continue
        for k,v in Tk[j].items():P[k]=P.get(k,Q(0))+Q(cj)*v/D
        P[0]-=Q(cj)*Tk[j].get(0,0)/D
    P={i:v for i,v in P.items() if v}
    B={}
    for i,v in P.items():
        B[i]=B.get(i,Q(0))+v;B[i+2]=B.get(i+2,Q(0))-v
    return P,{i:v for i,v in B.items() if v}

def centered_differences(B):
    # C=(B(m+x)-B(m-x))/(2x), A=(2B(m)-B(m+x)-B(m-x))/(2x^2)
    C,A={},{}
    for n,v in B.items():
        for j in range(1,n+1,2):
            C[n-j,j-1]=C.get((n-j,j-1),Q(0))+v*comb(n,j)
        for j in range(2,n+1,2):
            A[n-j,j-2]=A.get((n-j,j-2),Q(0))-v*comb(n,j)
    return {k:v for k,v in C.items() if v},{k:v for k,v in A.items() if v}

def power_to_bern_1(p,low=Q(-1),hi=Q(1)):
    n=max(p);coeff=[Q(0)]*(n+1)
    for k,v in p.items():
        for j in range(k+1):coeff[j]+=v*comb(k,j)*low**(k-j)*(hi-low)**j
    return [sum((coeff[j]*Q(comb(i,j),comb(n,j)) for j in range(i+1)),Q(0)) for i in range(n+1)]

def cert_poly_positive_univ(P):
    # The exact profile factor must remain strictly positive on [-1,1].
    # Subdivide only if initial Bernstein lower bounds are insufficient.
    arr=power_to_bern_1(P)
    pending=[(arr,0)];accepted=0;mini=None
    while pending:
        a,d=pending.pop();val=min(a)
        if val>0:
            accepted+=1;mini=val if mini is None else min(val,mini);continue
        if d>=30:raise RuntimeError('Profile-factor Bernstein check unresolved')
        left,right=split_line(a)
        pending.extend([(left,d+1),(right,d+1)])
    return {'status':'CERTIFIED','leaves':accepted,'minimum_lower_bound':str(mini)}

def split_line(vals):
    layers=[vals]
    while len(layers[-1])>1:layers.append([(a+b)/2 for a,b in zip(layers[-1][:-1],layers[-1][1:])])
    return [l[0] for l in layers],[l[-1] for l in reversed(layers)]

def split_bern(a,axis):
    if axis==0:
        pairs=[split_line(list(col)) for col in zip(*a)]
        return [list(x) for x in zip(*(p[0] for p in pairs))],[list(x) for x in zip(*(p[1] for p in pairs))]
    pairs=[split_line(v) for v in a]
    return [p[0] for p in pairs],[p[1] for p in pairs]

PIECES=[(-16,2,0,2),(-14,8,2,4),(-6,6,6,0), (0,6,6,0),(6,8,6,-4),(14,2,2,-2)]

def to_square(poly,piece):
    m0,dm,b0,db=piece
    max_m=max(i for i,j in poly);max_x=max(j for i,j in poly)
    m_poly=[(1,)];x_poly=[(1,)]
    for i in range(1,max_m+1):
        prev=m_poly[-1];out=[0]*(len(prev)+1)
        for k,v in enumerate(prev):out[k]+=m0*v;out[k+1]+=dm*v
        m_poly.append(tuple(out))
    for j in range(1,max_x+1):
        prev=x_poly[-1];out=[0]*(len(prev)+1)
        for k,v in enumerate(prev):out[k]+=b0*v;out[k+1]+=db*v
        x_poly.append(tuple(out))
    coeff={}
    for (i,j),v in poly.items():
        a,b=m_poly[i],x_poly[j]
        rat=v/Q(16)**(i+j)
        for ai,av in enumerate(a):
            if av==0:continue
            for bj,bv in enumerate(b):
                if bv==0:continue
                k=(ai+bj,j);coeff[k]=coeff.get(k,Q(0))+rat*av*bv
    return {k:v for k,v in coeff.items() if v}

def bernstein_tensor(poly):
    nx=max(i for i,j in poly);ny=max(j for i,j in poly)
    # Two 1-D power-to-Bernstein transformations, with precomputed weights.
    coeff=[[Q(0) for _ in range(ny+1)] for _ in range(nx+1)]
    for (i,j),v in poly.items():coeff[i][j]=v
    W_x=[[Q(comb(i,k),comb(nx,k)) for k in range(i+1)] for i in range(nx+1)]
    inter=[[sum((w*coeff[k][j] for k,w in enumerate(W_x[i]) if coeff[k][j]),Q(0))
            for j in range(ny+1)] for i in range(nx+1)]
    W_y=[[Q(comb(j,k),comb(ny,k)) for k in range(j+1)] for j in range(ny+1)]
    return [[sum((w*inter[i][k] for k,w in enumerate(W_y[j]) if inter[i][k]),Q(0))
             for j in range(ny+1)] for i in range(nx+1)]

def split_line_int(vals):
    """Rigorous downward-rounded de Casteljau at x=1/2 for integer lower bounds."""
    layers=[vals]
    while len(layers[-1])>1:
        layers.append([(a+b)//2 for a,b in zip(layers[-1][:-1],layers[-1][1:])])
    return [r[0] for r in layers],[r[-1] for r in reversed(layers)]

def split_bern_int(a,axis):
    if axis==0:
        pairs=[split_line_int(list(col)) for col in zip(*a)]
        return [list(x) for x in zip(*(p[0] for p in pairs))],[list(x) for x in zip(*(p[1] for p in pairs))]
    pairs=[split_line_int(row) for row in a]
    return [pair[0] for pair in pairs],[pair[1] for pair in pairs]

def certify_square(poly,piece,max_depth=34,bits=256):
    # Convert exact rational Bernstein coefficients to downward-rounded
    # dyadic integer lower bounds. Because the tensor Bernstein basis is
    # nonnegative and forms a partition of unity, and de Casteljau uses
    # only convex combinations, every subsequent lower bound is rigorous.
    exact=bernstein_tensor(to_square(poly,piece))
    D=1<<bits
    table=[[v.numerator*D//v.denominator for v in row] for row in exact]
    stack=[(table,0)];accepted=0;mini=None;depthmax=0
    while stack:
        a,depth=stack.pop();low=min(min(r) for r in a)
        if low>0:
            accepted+=1;mini=low if mini is None else min(mini,low)
            depthmax=max(depthmax,depth);continue
        if depth>=max_depth:raise RuntimeError(f'Unresolved Bernstein leaf: piece={piece} depth={depth}')
        left,right=split_bern_int(a,depth%2)
        stack.extend([(left,depth+1),(right,depth+1)])
    return {'leaves':accepted,'max_depth':depthmax,'dyadic_precision_bits':bits,
            'minimum_lower_bound':str(Q(mini,D))}

def s_interval(row):
    a,b=map(Q,row['interval'])
    if row['coord']=='s':return a,b
    return sq_floor(1-b*b,scale=10**9)[0],sq_floor(1-a*a,scale=10**9)[1]

def closure_certificate(row):
    _,B=profile_coeff(row)
    C,A=centered_differences(B)
    a,bb=s_interval(row)
    wlo=sq_floor(1+a,scale=10**9)[0];whi=sq_floor(1+bb,scale=10**9)[1]
    F={ (i,0):v for i,v in B.items() }
    phi=Q(row['phi']);eta=Q(row['eta']);mu=Q(row['mu']);L=Q(DATA['kernels'][row['family']][0])/2
    correction=pm(A,pa(pa(F,ps(pm({(0,1):Q(1)},C),2*phi-1)),ps(pm({(0,2):Q(1)},A),eta-1)))
    steps={}
    for name,w in [('lower',wlo),('upper',whi)]:
        K=pa({(0,0):1+w},ps(C,-(w*w-1)/L))
        Qpol=pa(ps(pm(K,K),mu),ps(correction,-1))
        steps[name]={'K':[],'closure':[]}
        for piece in PIECES:
            steps[name]['K'].append(certify_square(K,piece))
            steps[name]['closure'].append(certify_square(Qpol,piece))
    return {'status':'CERTIFIED','method':'Exact tensor Bernstein plus endpoint minimum of positive K',
        'w_enclosure':[str(wlo),str(whi)],'records':steps}

# Exact 3-bit enumeration and fixed-point evaluation.
def three_bit_data(B):
    out=[];allpolys=set()
    for mask in range(256):
        row=[(mask>>x)&1 for x in range(8)]
        if any(row[x]>row[x|(1<<j)] for x in range(8) for j in range(3)):continue
        polys=[]
        for x in range(8):
            counts=[sum(row[y] for y in range(8) if (x^y).bit_count()==j) for j in range(4)]
            coeff=tuple(sum(counts[j]*comb(3-j,k-j)*(-1)**(k-j) for j in range(k+1)) for k in range(4))
            polys.append(coeff)
        count=sum(row);mean=Q(count,4)-1
        dictator=count==4 and len(set(polys))==2 and set(polys)=={(0,1,0,0),(1,-1,0,0)}
        if count in [0,8] or dictator:continue
        bp=sum((v*mean**i for i,v in B.items()),Q(0))
        out.append((mask,polys,bp));allpolys.update(polys)
    assert len(out)==15
    return out,sorted(allpolys)

def F_interval(t):
    t=I(max(0,t.lo),min(SCALE,t.hi))
    # F is increasing on [0,1/2]; reduce t by reflection.
    if t.lo<=SCALE//2<=t.hi:r=I(min(t.lo,SCALE-t.hi),SCALE//2)
    elif t.hi<SCALE//2:r=t
    else:r=I(SCALE-t.hi,SCALE-t.lo)
    if r.lo==r.hi==0:return ii(0)
    return I(max(0,(sqrtI(r)+sqrtI(ii(1)-r)-ii(1)).lo),
             (sqrtI(r)+sqrtI(ii(1)-r)-ii(1)).hi)

def G_interval(t,co):
    if t.lo==t.hi==0 or t.lo==t.hi==SCALE:return ii(0)
    f=F_interval(t)
    L=horner(co,f)
    if L.lo<=0:raise ArithmeticError('Kernel polynomial positivity not enclosed')
    return f*(ii(2)*t+f*L)/(ii(1)+f*L)

def base_certificate(row,max_depth=29):
    _,B=profile_coeff(row)
    co=list(map(Q,DATA['kernels'][row['family']]))
    sources,polys=three_bit_data(B)
    plo,phi=noise_interval(row)
    stack=[(plo,phi,0)];leaves=0;depthmax=0;lower=None
    while stack:
        lo,hi,depth=stack.pop()
        p=I(ii(lo).lo,ii(hi).hi)
        try:
            values={}
            for terms in polys:
                t=horner(terms,p)
                t=I(max(0,t.lo),min(SCALE,t.hi))
                if t.lo>t.hi:raise ArithmeticError('Invalid noisy probability')
                values[terms]=G_interval(t,co)
            c=F_interval(p)
            lows=[(sum((values[t] for t in terms),ii(0))/8-c*ii(bp)).lo for mask,terms,bp in sources]
            good=min(lows)>0
        except (ArithmeticError,AssertionError,ZeroDivisionError):good=False
        if good:
            leaves+=1;depthmax=max(depthmax,depth)
            lower=min(lows) if lower is None else min(lower,min(lows))
        else:
            if depth>=max_depth:raise RuntimeError(f'Unresolved base case in {row["name"]} at p interval [{lo},{hi}]')
            mid=(lo+hi)/2
            stack.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
    return {'status':'CERTIFIED','nontrivial_functions':15,'slabs':leaves,'max_depth':depthmax,'minimum_lower_bound':str(Q(lower,SCALE))}

def run(row,checks):
    result={'name':row['name'],'input_profile_length':len(row['profile_c'])}
    if 'positive' in checks:
        P,B=profile_coeff(row);result['positive']=cert_poly_positive_univ(P)
    if 'base' in checks:result['base']=base_certificate(row)
    if 'closure' in checks:result['closure']=closure_certificate(row)
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--row',type=int,required=True,help='1..20')
    ap.add_argument('--checks',nargs='+',choices=['positive','base','closure'],default=['positive','base','closure'])
    ap.add_argument('--out');a=ap.parse_args()
    if not 1<=a.row<=20:raise ValueError('Row must be in 1..20')
    start=time.monotonic()
    result={'status':'UNVERIFIED'}
    try:
        result=run(DATA['rows'][a.row-1],a.checks)
        result.update(status='CERTIFIED',checks=a.checks,elapsed_seconds=round(time.monotonic()-start,2))
    finally:
        out=Path(a.out) if a.out else ROOT/'results'/f'half_row_{a.row:02d}_{"_".join(a.checks)}.json'
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'row':a.row,'seconds':result['elapsed_seconds']},indent=2))

#!/usr/bin/env python3
"""Transcribe the 20 square-root certification rows verbatim from the supplied TeX.

The source is a manuscript snapshot, not an independently validated result.
No test that is a tautological interval union or normalization is represented
as a computational proof obligation.
"""
from pathlib import Path
from fractions import Fraction
import hashlib, json, re

ROOT=Path(__file__).resolve().parent.parent
TEX=ROOT/'manuscript_snapshot.tex'
OUT=Path(__file__).resolve().parent/'theorem1_rows.json'

def clean_tex(tex):
    return '\n'.join(row.split('%')[0] for row in tex.splitlines())

def dec(x):
    x=x.strip().replace(' ', '')
    if x.startswith('.') or x.startswith('-.'): x=x.replace('.', '0.',1)
    return str(Fraction(x))

def main():
    source=TEX.read_text()
    text=clean_tex(source)
    s=text[text.index(r'\section{Profile data for $1/2$-stability}'):]
    vector_spans=re.findall(r'\\boldsymbol c=\(&(.+?)\)\s*\.?\s*\\end\{aligned\}',s,re.S)
    vectors=[[int(v) for v in re.findall(r'-?\d+',span)] for span in vector_spans]
    if len(vectors)!=20:raise ValueError(f'Expected 20 square-root profiles; found {len(vectors)}')
    first=text[text.index(r'\label{tab:all-intervals}'):text.index(r'\end{table}',text.index(r'\label{tab:all-intervals}'))]
    entries=[]
    rx=re.compile(r'(I|II)&\$\[([0-9.]+),([0-9.]+)\]\$&([0-9.]+)&([0-9.]+)&([0-9.]+)&(\d+)\\\\')
    for fam,lo,hi,phi,eta,mu,degree in rx.findall(first):
        entries.append(dict(family=fam,coord='s',interval=[dec(lo),dec(hi)],phi=dec(phi),eta=dec(eta),mu=dec(mu),d=int(degree)))
    if len(entries)!=14:raise ValueError(f'Expected 14 legacy rows: {len(entries)}')
    second=text[text.index(r'\label{tab:half-extra}'):text.index(r'\end{table}',text.index(r'\label{tab:half-extra}'))]
    rx2=re.compile(r'(II|III|IV)\s*&\s*\$(s|\\rho)\\in\[([0-9.]+),([0-9.]+)\]\$\s*&\s*([0-9.]+)\s*&\s*([0-9.]+)\s*&\s*([0-9.]+)\s*&\s*(\d+)\\\\')
    for fam,coord,lo,hi,phi,eta,mu,degree in rx2.findall(second):
        entries.append(dict(family=fam,coord='s' if coord=='s' else 'rho',interval=[dec(lo),dec(hi)],phi=dec(phi),eta=dec(eta),mu=dec(mu),d=int(degree)))
    if len(entries)!=20:raise ValueError(f'Expected 20 table rows: {len(entries)}')
    # Profile vector ordering differs from the order in Table 1.
    indices=[10,11,12,13,4,5,6,3,4,5,6,7,8,9,14,15,16,17,18,19]
    names=['II-1','II-2','II-3','II-4','I-1','I-2','I-3','I-4','I-5','I-6','I-7','I-8','I-9','I-10','II-propagated','III-1','III-2','III-3','III-4','IV-1']
    # NB: assign Family I rows according to the interval, NOT the repeated d.
    # Correct index order for Table 1 after four Family II rows:
    indices=[10,11,12,13,0,1,2,3,4,5,6,7,8,9,14,15,16,17,18,19]
    for idx,(row,v_i,nm) in enumerate(zip(entries,indices,names)):
        row['name']=nm
        row['profile_c']=vectors[v_i]
        row['profile_denominator']=10**(8 if idx<14 else 12 if idx==14 else 14)
        if len(row['profile_c'])!=row['d']:
            raise ValueError(f'Profile length mismatch in {nm}: {len(row["profile_c"])} != {row["d"]}')
    kernels={
      'I':[Fraction(x) for x in ['26/20','-7/20','4/20','31/20','18/20','3/20']],
      'II':[Fraction(x) for x in ['660/500','-146/500','-44/500','529/500','324/500','54/500']],
      'III':[Fraction(x) for x in ['132612675/100000000','-47653920/100000000','53479214/100000000','102660617/100000000']],
      'IV':[Fraction(x) for x in ['1.32889710','-1.02325943','3.03035249','0.80706624','-9.25961996','-8.97492640','35.00400827']],
    }
    data={'source_file':TEX.name,'source_sha256':hashlib.sha256(TEX.read_bytes()).hexdigest(),
          'meaning':'Input coefficients transcribed from the manuscript, not proof certificates',
          'kernels':{k:[str(c) for c in v] for k,v in kernels.items()},'rows':entries}
    OUT.write_text(json.dumps(data,indent=2)+'\n')
    print('Extracted',len(entries),'square-root rows into',OUT)

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Run three independent full-domain C++ proofs for each half-order row.

Compile all 20 binaries first with `python generate_sqrt_pair.py --compile`.
A box count limit, interruption, failure or checkpoint is NOT a certificate.
Only an exit code zero together with status CERTIFIED is accepted.
"""
import argparse,json,subprocess,sys,time,hashlib
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
P=Path(__file__).resolve().parent

def one(row,region,maxboxes,skip_verified=False):
    binary=P/'pair_cpp'/'bin'/f'verify_sqrt_{row:02d}'
    if not binary.is_file():return {'row':row,'region':region,'status':'MISSING BINARY: UNVERIFIED'}
    destination=P/'results'/'pairs';destination.mkdir(parents=True,exist_ok=True)
    receipt_path=destination/f'pair_{row:02d}_{region}_receipt.json'
    if skip_verified and receipt_path.exists():
        old=json.loads(receipt_path.read_text())
        binary_sha=hashlib.sha256(binary.read_bytes()).hexdigest()
        if old.get('status')=='CERTIFIED' and old.get('binary_sha256')==binary_sha and old.get('program_output',{}).get('status')=='CERTIFIED: all boxes strictly positive':
            return old
    checkpoint=destination/f'pair_{row:02d}_{region}_incomplete.json'
    cmd=[str(binary),region,str(maxboxes),str(checkpoint)]
    t=time.monotonic()
    completed=subprocess.run(cmd,capture_output=True,text=True)
    (destination/f'pair_{row:02d}_{region}.stderr.log').write_text(completed.stderr)
    (destination/f'pair_{row:02d}_{region}.stdout.log').write_text(completed.stdout)
    last=completed.stdout.strip().splitlines()[-1] if completed.stdout.strip() else '{}'
    try:payload=json.loads(last)
    except json.JSONDecodeError:payload={'status':'OUTPUT ERROR: UNVERIFIED','stdout_tail':last[:300]}
    good=completed.returncode==0 and payload.get('status')=='CERTIFIED: all boxes strictly positive'
    record={'row':row,'region':region,'status':'CERTIFIED' if good else 'UNVERIFIED',
        'return_code':completed.returncode,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
        'elapsed_seconds':round(time.monotonic()-t,3),'program_output':payload}
    (destination/f'pair_{row:02d}_{region}_receipt.json').write_text(json.dumps(record,indent=2)+'\n')
    return record

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--rows',nargs='+',type=int,default=list(range(1,21)))
    ap.add_argument('--regions',nargs='+',choices=['left','right','cross'],default=['left','right','cross'])
    ap.add_argument('--jobs',type=int,default=2)
    ap.add_argument('--max-boxes',type=int,default=10000000)
    ap.add_argument('--skip-verified',action='store_true',help='Reuse completed receipts only if the binary SHA256 matches')
    args=ap.parse_args()
    if not all(1<=r<=20 for r in args.rows):raise ValueError('Row must be in [1,20]')
    tasks=[(i,j,args.max_boxes,args.skip_verified) for i in args.rows for j in args.regions]
    receipts=[]
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        future={pool.submit(one,*t):t for t in tasks}
        for completed in as_completed(future):
            receipt=completed.result();receipts.append(receipt)
            print(receipt['row'],receipt['region'],receipt['status'],flush=True)
    failed=[x for x in receipts if x['status']!='CERTIFIED']
    out={'status':'CERTIFIED' if not failed else 'INCOMPLETE: NOT A FULL PROOF',
         'number_certified':len(receipts)-len(failed),'number_tasks':len(tasks),'receipts':receipts}
    (P/'results'/'pair_certification_ledger.json').write_text(json.dumps(out,indent=2)+'\n')
    if failed:
        print(f'{len(failed)} domains were not certified; inspect receipts',file=sys.stderr)
        sys.exit(1)
    print('All requested pair regions CERTIFIED')

if __name__=='__main__':main()

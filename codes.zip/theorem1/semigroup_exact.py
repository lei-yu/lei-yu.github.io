#!/usr/bin/env python3
"""Exact, independently recomputed nontrivial rational certificates in Appendix A.

No sampled floating-point tests are treated as proof. All tests are exact
rational identities or positivity of every Bernstein coefficient, except the
D-derivative certificate, which uses its stated monomial-coefficient grouping.
Use --only to select an individual time-consuming proof obligation.
"""
import argparse, json, math, time
from pathlib import Path
from fractions import Fraction
import sympy as S
q=S.Rational


def bernstein1(poly,x,lo=0,hi=1):
    p=poly if isinstance(poly,S.Poly) else S.Poly(poly,x)
    n=p.degree()
    # Exact affine substitution directly on coefficients; avoids large symbolic expansions.
    c=[Fraction(0) for _ in range(n+1)]
    for k in range(n+1):
        a=Fraction(p.nth(k))
        for j in range(k+1):
            c[j]+=a*Fraction(math.comb(k,j))*Fraction(lo)**(k-j)*Fraction(hi-lo)**j
    return [sum((c[k]*Fraction(math.comb(i,k),math.comb(n,k)) for k in range(i+1)),Fraction(0)) for i in range(n+1)]

def bernstein2(poly,x,y,lo_y=0,hi_y=1):
    p=S.Poly(S.expand(poly.subs(y,lo_y+(hi_y-lo_y)*y)),x,y)
    nx,ny=p.degree(x),p.degree(y)
    d=p.as_dict()
    co={(i,j):Fraction(v) for (i,j),v in d.items()}
    # Tensor Bernstein coefficient beta[i,j], exact rational.
    return [[sum((v*Fraction(math.comb(i,k),math.comb(nx,k))*Fraction(math.comb(j,l),math.comb(ny,l))
                for (k,l),v in co.items() if k<=i and l<=j),Fraction(0))
             for j in range(ny+1)] for i in range(nx+1)]

def assert_positive(v, name):
    z=min(v)
    if z<=0: raise AssertionError(f'{name} nonpositive Bernstein coefficient {z}')
    return {'status':'PASS','minimum':str(z),'floor_1e6':int(z*1000000)}

def omega_identity():
    z,t=S.symbols('z t')
    A=4*(1-z)**2*(1+3*z)*(2+z+z*z)
    B=(1+z)*(4*(1-z)**2*(1+3*z)**2+3*z*z*(5-z)*(5+10*z+z*z))
    r=t*A.subs(z,t*t)/B.subs(z,t*t)
    ell=3*t*(1+t*t)*(5+10*t*t+t**4)/(4*(1-t*t)**2*(1+3*t*t))
    drdx=S.diff(r,t)*(1+t*t)**2/(2*(1-t*t))
    Q=100+920*z+3745*z**2+9165*z**3+14768*z**4+16128*z**5+12098*z**6+6210*z**7+2036*z**8+336*z**9+21*z**10+9*z**11
    target=12*z*z*Q/((1+3*z)*B*B)
    remainder=S.cancel(1-ell*r-drdx-target.subs(z,t*t))
    if remainder!=0:raise AssertionError('Omega derivative identity differs from manuscript')
    return {'status':'PASS','identity':'sg:omega-identity'}

def derivative_certificate():
    w,t,y=S.symbols('w t y')
    Y=2*w*w-1
    N=48*y*(4+2*y-y*y)-25*w*(1-y)*(1+y)**2*(2-y)**2
    P=14400*w*y**3*(2-y)**3*(1+y)**2-N**2
    numer=S.Poly(S.expand(P.subs(y,Y)),w)
    quotient,rem=S.div(numer,S.Poly(64*(1-w),w));assert rem.is_zero
    CD=S.Poly(S.expand(5**17*quotient.as_expr().subs(w,(4+t)/5)),t)
    negatives=[i for i in range(CD.degree()+1) if CD.nth(i)<0]
    assert negatives==[5,6,7],negatives
    assert [CD.nth(i) for i in (4,5,6,7)]==[515636013679740,-129753241411356,-202277501092524,-64518339810120]
    assert CD.nth(4)+CD.nth(5)+CD.nth(6)+CD.nth(7)>0
    assert all(CD.nth(i)>=0 for i in range(CD.degree()+1) if i not in (5,6,7))
    return {'status':'PASS','degree':CD.degree(),'negative_indices':negatives}

def ode_comparisons():
    u,z=S.symbols('u z')
    D=2*(2-u*u);C=u**3*(5-u*u);B=8*(2-u*u)**4*(1+u*u)
    def R(c):return D*(1-u**4)*(2+2*c*(1-u))+C*(1+2*(1-u)+c*(1-u)**2)
    Rs=D*(1-u**4)*(2+q(13,20)*(1-u))+C*(1+2*(1-u)+q(57,100)*(1-u)**2)
    tests=[('lower', B-R(q(3,8))**2,3,[(0,1,7000000,11)]),
           ('upper', R(q(57,100))**2-B,2,[(0,q(1,2),1585784,12),(q(1,2),1,1447469,12)]),
           ('derivative',B-Rs**2,2,[(0,1,160000,12)])]
    result={}
    for name,expr,power,intervals in tests:
        poly=S.Poly(S.expand(expr.subs(u,1-z)),z)
        if any(poly.nth(i)!=0 for i in range(power)):raise AssertionError(f'{name} invalid factor')
        reduced=S.cancel(poly.as_expr()/z**power)
        sub={}
        for lo,hi,expected,degree in intervals:
            arr=bernstein1(reduced,z,lo,hi)
            assert len(arr)-1==degree,(name,len(arr),degree)
            res=assert_positive(arr,f'{name} {lo}:{hi}')
            # Compare certified rounded bound; higher is okay if mathematically exact.
            assert res['floor_1e6']>=expected,(name,res,expected)
            sub[f'{lo},{hi}']=res
        result[name]=sub
    return result

def c_derivative():
    t,z=S.symbols('t z')
    polynomial=S.Poly(32-(5-3*t)**2*(1+t*t)**3,t)
    assert polynomial.eval(1)==0 and polynomial.diff().eval(1)==0
    reduced=S.cancel(polynomial.as_expr()/(1-t)**2)
    vals=bernstein1(reduced.subs(t,1-z),z,0,1)
    expect=[q(72),q(172,3),q(628,15),q(152,5),q(322,15),q(43,3),q(7)]
    assert list(map(S.Rational,vals))==expect,(vals,expect)
    return {'status':'PASS','minimum':str(min(vals))}

def bregman():
    b,e=S.symbols('b e')
    RB=4+q(13,30)*b+q(13,15)*e+(1+q(5,2)*e+q(11,8)*e**2+q(3,16)*e**3)*(1+b/2+e)
    BB=1+b+e+q(19,100)*(b*b+b*e+e*e)
    poly=S.expand(RB-16*q(153,2000)*BB**2)
    co=bernstein2(poly,b,e,0,q(17,200))
    actual=[min(row) for row in co]
    expect=[3776000,3397333,2737146,1679160,11812]
    if [int(v*1000000) for v in actual]!=expect:raise AssertionError(f'Bregman minima differ: {[int(v*1000000) for v in actual]} != {expect}')
    return {'status':'PASS','row_minima':list(map(str,actual))}

def calibration():
    z=S.symbols('z')
    one=S.Poly(1,z); r=S.Poly(2*z-z*z,z); s=S.Poly(1-z,z)
    Q=one+q(5,16)*r+q(81,512)*r**2+q(5937,57344)*r**3+q(39435,524288)*r**4
    term=one+q(1,4)*r**2*Q**2
    poly=32*Q**4*s**6*(2*one-s)**2*(one+s)**3*term**4-(s**2+s+2*one)**4
    assert poly.degree()==123,poly.degree()
    assert poly.nth(0)==0 and poly.nth(1)==0
    # Polynomial division by z^2 is a coefficient shift, not symbolic cancel().
    reduced=S.Poly.from_dict({(i-2,):v for (i,),v in poly.terms() if i>=2},z)
    arr=bernstein1(reduced,z,0,q(4,25))
    out=assert_positive(arr,'calibration polynomial')
    assert len(arr)==122
    assert out['floor_1e6']>=10182120,out
    return out

CHECKS={'omega':omega_identity,'derivative':derivative_certificate,'ode':ode_comparisons,'cderivative':c_derivative,'bregman':bregman,'calibration':calibration}
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--only',choices=CHECKS);ap.add_argument('--output');args=ap.parse_args()
    result={};start=time.monotonic()
    try:
        for label,func in CHECKS.items():
            if args.only and args.only!=label:continue
            t=time.monotonic();result[label]=func()
            result[label]['seconds']=round(time.monotonic()-t,3)
            print(label,'PASS',result[label]['seconds'],'s',flush=True)
        result['overall']='PASS'
    except Exception as e:
        result['overall']='FAIL';result['failure']=repr(e)
        print('FAIL:',repr(e),flush=True)
        raise
    finally:
        if args.output:Path(args.output).write_text(json.dumps(result,indent=2)+'\n')
    print('All selected exact polynomial certificates passed in',round(time.monotonic()-start,1),'s')

#!/usr/bin/env python3
"""Additional, nontrivial exact Bernstein bounds cited in the manuscript.

These are distinct from the scalar normalizations and interval adjacency,
which follow algebraically and therefore need no numeric certification.
"""
import json, hashlib, argparse
from pathlib import Path
from fractions import Fraction as Q
from profile_base_exact import profile_coeff, cert_poly_positive_univ, DATA
from generate_sqrt_pair import bernstein

ROOT=Path(__file__).resolve().parent

def poly_diff(B):return {i-1:Q(i)*v for i,v in B.items() if i}
def poly_sub_constant(poly,c):
    poly=dict(poly);poly[0]=poly.get(0,Q(0))-Q(c);return poly

def one_row(rowid,kind):
    row=DATA['rows'][rowid-1]
    P,B=profile_coeff(row)
    if kind=='derivative':
        dB=poly_diff(B)
        pol={i:-c for i,c in dB.items()};pol[0]=pol.get(0,Q(0))+Q(3)
        result=cert_poly_positive_univ(pol)
        return {'row':rowid,'bound':'3-B_prime(m)>0 for -1<=m<=1',**result}
    if kind=='factor':
        pol=poly_sub_constant(P,Q(5387,10000))
        result=cert_poly_positive_univ(pol)
        return {'row':rowid,'bound':'B(m)/(1-m^2)>5387/10000 for -1<m<1',**result}
    raise ValueError(kind)

def lambda_IV():
    coeff=[Q(c) for c in DATA['kernels']['IV']]
    assert len(coeff)==7
    target=Q(1916794877,8640000000)
    diff=list(coeff);diff[0]-=1+target
    bound=bernstein(diff,Q(0),Q(5,12))
    if min(bound)<0:raise AssertionError('IV quantitative kernel lower bound failed')
    return {'status':'CERTIFIED','bound':'Lambda_IV(x)-1>=1916794877/8640000000 on 0<=x<=5/12',
       'minimum_Bernstein_residual':str(min(bound)),'Bernstein_order':len(bound)-1}

def main():
    result={'status':'UNVERIFIED'}
    try:
        details={'extension_B_prime':{str(i):one_row(i,'derivative') for i in range(15,21)},
            'degree_six_profile_factor':one_row(20,'factor'),
            'degree_six_lambda_margin':lambda_IV()}
        result={'status':'CERTIFIED','details':details}
    finally:
        out=ROOT/'results'/'supplementary_exact.json'
        out.parent.mkdir(exist_ok=True)
        out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
if __name__=='__main__':main()

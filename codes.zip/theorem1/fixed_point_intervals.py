#!/usr/bin/env python3
"""Directed 192-bit fixed-point intervals for independently derived square-root auxiliary checks.

The arithmetic operations were copied unchanged from the original interval
support module. They support exact rational input and outward enclosures.
"""
from dataclasses import dataclass
from fractions import Fraction
from math import isqrt
from decimal import Decimal, localcontext

BITS = 192
SCALE = 1 << BITS

def ceil_div(a, b):
    assert b > 0
    return -((-a) // b)

@dataclass(frozen=True)
class I:
    lo: int
    hi: int

    def __post_init__(self):
        assert self.lo <= self.hi

    @staticmethod
    def rational(n, d=1):
        assert d > 0
        return I(n*SCALE//d, ceil_div(n*SCALE, d))

    def __add__(self, x):
        if isinstance(x, int): x=I.rational(x)
        return I(self.lo+x.lo, self.hi+x.hi)
    __radd__=__add__

    def __neg__(self): return I(-self.hi, -self.lo)
    def __sub__(self, x):
        if isinstance(x, int): x=I.rational(x)
        return self+-x
    def __rsub__(self, x): return -self+x

    def __mul__(self, x):
        if isinstance(x, int): x=I.rational(x)
        v=[self.lo*x.lo,self.lo*x.hi,self.hi*x.lo,self.hi*x.hi]
        return I(min(v)//SCALE,ceil_div(max(v),SCALE))
    __rmul__=__mul__

    def __truediv__(self, x):
        if isinstance(x, int): x=I.rational(x)
        assert x.lo > 0
        v=[Fraction(self.lo*SCALE,x.lo), Fraction(self.lo*SCALE,x.hi),
           Fraction(self.hi*SCALE,x.lo), Fraction(self.hi*SCALE,x.hi)]
        lo=min(v);hi=max(v)
        return I(lo.numerator//lo.denominator,
                 ceil_div(hi.numerator,hi.denominator))

    def square(self):
        assert self.lo >= 0
        return self*self

    def display(self):
        with localcontext() as c:
            c.prec=65
            return [str(Decimal(self.lo)/Decimal(SCALE)),
                    str(Decimal(self.hi)/Decimal(SCALE))]

ONE=I.rational(1)

def sqrt_fraction(n,d):
    assert n >= 0 and d > 0
    v=isqrt(n*SCALE*SCALE//d)
    exact=(v*v*d==n*SCALE*SCALE)
    return I(v,v if exact else v+1)


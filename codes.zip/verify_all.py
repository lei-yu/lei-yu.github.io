#!/usr/bin/env python3
"""Recompute the nontrivial computer-assisted certificates for the 2026 manuscript.

Run explicit subcommands; no sampled check is accepted as a proof. The external
Hellinger contraction theorem and the manuscript's unproved local statement
are NOT assertions established by this software.
"""
import argparse, subprocess, sys
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def execute(args, cwd):
    print('RUN', ' '.join(map(str,args)), 'in', cwd.relative_to(ROOT), flush=True)
    subprocess.run([str(s) for s in args], cwd=cwd, check=True)

def main():
    p=argparse.ArgumentParser(description=__doc__,formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument('target',choices=['theorem1-aux','theorem1-pairs','theorem2-aux','theorem2-pairs','all'])
    p.add_argument('--jobs',type=int,default=3)
    p.add_argument('--reuse-exact-receipts',action='store_true',help='Reuse local Theorem 1 receipts only when their status and binary digest match. Not a fresh proof.')
    a=p.parse_args()
    if a.jobs<1:p.error('--jobs must be positive')
    t=ROOT/'theorem1';t2=ROOT/'theorem2';py=sys.executable
    if a.target in ('theorem1-aux','all'):
        execute([py,'semigroup_exact.py','--output','results/semigroup_exact.json'],t)
        execute([py,'supplementary_exact.py'],t)
        execute([py,'run_all_profiles.py','--checks','positive','base','--jobs',a.jobs]+(['--skip-verified'] if a.reuse_exact_receipts else []),t)
        execute([py,'run_all_profiles.py','--checks','closure','--jobs',a.jobs]+(['--skip-verified'] if a.reuse_exact_receipts else []),t)
    if a.target in ('theorem1-pairs','all'):
        execute([py,'generate_sqrt_pair.py','--compile'],t)
        execute([py,'run_sqrt_pairs.py','--jobs',a.jobs]+(['--skip-verified'] if a.reuse_exact_receipts else []),t)
    if a.target in ('theorem2-aux','theorem2-pairs','all'):
        opts=['--aux-only'] if a.target=='theorem2-aux' else ['--jobs',a.jobs]
        execute([py,'verify_nontrivial.py',*opts],t2)
    print('CERTIFIED the selected finite proof obligations. External analytic premises must be established separately.',flush=True)
if __name__=='__main__':main()

# Verification code for *Symmetric Noise Stability on the Hypercube: Near Half-Order*

**Paper:** Lei Yu, PDF dated **26 October 2026**, 30 pages (`NoiseStability-20261026(1).pdf`).  
**Purpose:** An explicit cross-reference between **each computational proof obligation in the paper** and the corresponding scripts, source data, and certificate records in this archive.

> **Scope and status are essential.** The package verifies *finite* polynomial, interval, and pair-residual inequalities. It does not automatically prove the surrounding analytic arguments. In the supplied archive, **Theorem 1 has 60 archived completed pair receipts and all 20 profile/closure/base records**, whereas **Theorem 2 has five archived auxiliary records and a historical summary of 15 completed pair regions, but no archived fresh-run output for those 15 regions**. The external Hellinger contraction theorem and the local-dictator assertion (3) are **not verified by this package**. The status below describes what was *present in the uploaded ZIP*, not a new full computation performed while writing this README.

## 1. Paper-to-code overview

| Paper item (PDF numbering) | Required computer-assisted facts | Code / inputs | Evidence included in the ZIP |
|---|---|---|---|
| **Theorem 1**, (2), Section 4; low-correlation portion | Polynomial identities and positivity certificates used in the proof of the energy inequality, **Lemma 5** | [`theorem1/semigroup_exact.py`](theorem1/semigroup_exact.py) | [`theorem1/results/semigroup_exact.json`](theorem1/results/semigroup_exact.json), with `overall: PASS` |
| **Theorem 1**, (2), Section 4; high-correlation portion | **Lemma 2**: 20 sets of hypotheses of **Proposition 1**, including pair (12), closure (13), three-bit base (14), profile positivity, and auxiliary bounds | [`theorem1/generate_sqrt_pair.py`](theorem1/generate_sqrt_pair.py), [`theorem1/run_sqrt_pairs.py`](theorem1/run_sqrt_pairs.py), [`theorem1/profile_base_exact.py`](theorem1/profile_base_exact.py), [`theorem1/run_all_profiles.py`](theorem1/run_all_profiles.py), [`theorem1/supplementary_exact.py`](theorem1/supplementary_exact.py) | 60 individual pair receipts, 20 closure records, 20 positivity/base records, additional rational bounds; see §3 |
| **Theorem 2**, (4), Section 5; `alpha = 13/25`, intermediate correlation | Five bands in (27): **Proposition 1** pair (12), closure (13), base (14), kernel/auxiliary positivity; scalar gate (15) follows separately by elementary parameter bounds | [`theorem2/verify_nontrivial.py`](theorem2/verify_nontrivial.py), [`theorem2/alpha_direct/closure/theorem2/certify_rational_alpha_aux.py`](theorem2/alpha_direct/closure/theorem2/certify_rational_alpha_aux.py), [`theorem2/alpha_direct/certification_generic/generate_and_build.py`](theorem2/alpha_direct/certification_generic/generate_and_build.py), [`theorem2/alpha_direct/certification_generic/verify_generic_hg.cpp`](theorem2/alpha_direct/certification_generic/verify_generic_hg.cpp) | Five auxiliary JSON results and a **historical** 15-region pair summary; see §4 for the critical distinction |
| **Theorem 2**, (4); high-correlation Hellinger tail | Positive tangent/supporting-line defect (28), Appendix C.4 | [`theorem2/alpha_direct/closure/theorem2/certify_rational_hellinger.py`](theorem2/alpha_direct/closure/theorem2/certify_rational_hellinger.py) | [`theorem2/results/theorem2_hellinger_certificate.json`](theorem2/results/theorem2_hellinger_certificate.json) |
| **Theorem 2**, (4); extension from `alpha = 13/25` to larger alpha | **Lemma 3** (upward transfer) and **Lemma 4** (convex minorant/supporting-line argument) | **Analytic proofs in the paper**; no standalone numerical checker required | Not applicable |
| **Theorem 3**, (22): Hellinger contraction | External theorem cited in the paper | **Not included / not code-proved** | No certificate is claimed |
| Introductory **local dictator bound (3)** | Additional claim for `delta(g) <= 1/10` and `49/50 <= rho <= 1` | **No corresponding local-stability proof/checker in this ZIP** | **Not covered**; requires a separate proof/source if retained |

The general dimension-induction statement **Proposition 1**, the symmetric deduction **Corollary 1**, and **Lemma 1** (coordinate sorting) are **analytic arguments**. The software certifies numerical premises of Proposition 1 for the specified kernels; it does **not** enumerate all Boolean functions or directly prove Proposition 1.

## 2. Appendix A: exact correspondence for Lemmas 5–12

The paper's Appendix A proves **Lemma 5** (energy inequality (33)) and uses **Lemmas 6–12**. Its **A.5** records polynomial positivity checks supporting **Lemmas 8, 9, and 11**; the **Lemma 7** polynomial check occurs earlier, in **A.1**. All six named computer checks below live in [`theorem1/semigroup_exact.py`](theorem1/semigroup_exact.py).

| Lemma / paper equation | Exact program routine | What the routine checks | Recorded result key |
|---|---|---|---|
| **Lemma 6**, convexity of `Omega`; identity (37), Appendix A.1 | `omega_identity()` | Symbolic identity producing the explicit positive-coefficient polynomial `Q_Omega`; the subsequent convexity implication is analytic | `omega` |
| **Lemma 7**, derivative bound (38), algebra after (40), Appendix A.1 | `derivative_certificate()` | Exact polynomial division, the degree-21 coefficient pattern, and the grouping of negative terms specified in the proof | `derivative` |
| **Lemma 8**, comparison-function bounds (42), Appendix A.2 / A.5 | `ode_comparisons()` | Four positive Bernstein checks for `B_0 - R_{3/8}^2`, `R_{57/100}^2 - B_0` (two intervals), and `B_0 - R_*^2` | `ode` |
| **Lemma 9**, derivative estimate (46), Appendix A.2 / A.5 | `c_derivative()` | Exact degree-six Bernstein coefficients for the derivative lower bound | `cderivative` |
| **Lemma 9**, strong scalar remainder (44), polynomial (50), Appendix A.2 / A.5 | `bregman()` | Positive tensor Bernstein coefficients for `R_B - 16(153/2000) B_B^2` on the full parameter rectangle | `bregman` |
| **Lemma 11**, excess-function bounds (53), reduction (55)–(56), Appendix A.3 / A.5 | `calibration()` | Exact factorization and positivity of the **degree-121** reduced polynomial in (56) | `calibration` (legacy **code name**; the current paper no longer uses this terminology) |
| **Lemma 10**, variance gain (51)–(52) | No separate checker | Derived analytically from Lemmas 7 and 9 and elementary inequalities | — |
| **Lemma 12**, centered-edge comparison (58) | No separate checker | Analytic convexity/centering and Fourier argument | — |
| **Lemma 5**, energy inequality (33) | No standalone theorem-wide numerical check | Assembled analytically using Lemmas 6–12 and the certified scalar prerequisites above | — |

To run all six finite Appendix-A checks only:

```sh
cd theorem1
python3 semigroup_exact.py --output results/semigroup_exact.json
```

To check one specific item, use `--only omega`, `--only derivative`, `--only ode`, `--only cderivative`, `--only bregman`, or `--only calibration`. The JSON key and function name `calibration` are retained from the code's earlier terminology and refer to **Lemma 11**.

## 3. Appendix B and Lemma 2: Theorem 1's 20 induction rows

**Definition of the obligation.** Proposition 1 in Section 3 requires, at every admissible parameter, **pair (12)** including kernel concavity/`D >= 0`, **closure (13)**, **three-bit base (14)**, and **gate (15)**. Lemma 2 and Appendix B apply these conditions to four kernel families, 20 mean profiles, and the bands in paper Table 1 / Appendix B.6.

| Paper subsection / condition | Script or source | Input and output; verification type |
|---|---|---|
| **B.1**, pair normalization (69), left (72), right (73), and cross chart; pair condition (12) | `theorem1/pair_cpp/verify_sqrt_pair.cpp` and support headers in `theorem1/pair_cpp/`; generated headers `theorem1/pair_cpp/generated/*.hpp`; generator `theorem1/generate_sqrt_pair.py` | The **three full-domain pair regions** for each of 20 rows, **60 C++ checks**. The diagonal limits supply strict concavity. `theorem1/run_sqrt_pairs.py` runs them and writes receipts. Generating/compiling headers is not proof of domain positivity. |
| **B.2**, verification method for closure (13), profile positivity and nontrivial base (14) | `theorem1/profile_base_exact.py`, dispatched by `theorem1/run_all_profiles.py` | Exact rational Bernstein checks for the full mean/influence region; profile factor positive on `[-1,1]`; **15 nontrivial increasing three-bit base cases per row** with directed integer square-root bounds. |
| **B.2**, gate (15) | The rational constants in `theorem1/theorem1_rows.json`, and the paper's explicit scalar comparison | **No separate multidimensional numerical certificate is needed**; verify the scalar rational inequality described below. Do not count kernel generation as a gate check. |
| **B.3**, Families I and II | Both pair and profile runners above | 14 legacy individual rows (I: 10, II: 4). The paper groups them into nine shared pair parameter bands (7 + 2); **this code instead verifies the rows individually**. |
| **B.4**, last Family-II interval, analytic extension (75) | Row 15 (`II-propagated`) in `theorem1/theorem1_rows.json`, all three C++ pair charts, and its profile/closure/base record | The **analytic propagation inequality itself is proved in the paper**. Independently, the supplied code directly certifies the final row's full pair band and auxiliary conditions. |
| **B.5**, Families III and IV | Rows 16–20, both runners; `theorem1/supplementary_exact.py` | Five rows / 15 pair charts plus closure/base/profile; extra `B'(m) < 3` bounds, a degree-six profile-factor lower bound, and the quantitative `Lambda_IV` margin. |
| **B.6**, exact profiles | `theorem1/theorem1_rows.json`; `theorem1/profile_base_exact.py` | Contains all 20 **exact integer Chebyshev coefficient vectors** and denominators; the script constructs `B(m)`. `B(0)=1` and `B(±1)=0` are algebraic identities, not numerical tests. |
| Equation (18), positivity of four kernel polynomials | `theorem1/generate_sqrt_pair.py`; strengthened Family-IV bound in `theorem1/supplementary_exact.py` | Rational Bernstein enclosures used during header generation, plus the explicit Family-IV bound in the supplementary scalar checker. |

**Important row-numbering convention:** `theorem1` code row IDs **do not follow the display order of paper Table 1**; they start with Family II. Use the following exact mapping, also used in `theorem1/pair_cpp/generated/` and result filenames:

| Code row | Kernel/profile | Paper parameter band |
|---:|---|---|
| 01 | II-1 | `s in [0.19, 0.195]` |
| 02 | II-2 | `s in [0.195, 0.21]` |
| 03 | II-3 | `s in [0.21, 0.24]` |
| 04 | II-4 | `s in [0.24, 0.28]` |
| 05 | I-1 | `s in [0.28, 0.33]` |
| 06 | I-2 | `s in [0.33, 0.38]` |
| 07 | I-3 | `s in [0.38, 0.49]` |
| 08 | I-4 | `s in [0.49, 0.51]` |
| 09 | I-5 | `s in [0.50, 0.60]` |
| 10 | I-6 | `s in [0.60, 0.70]` |
| 11 | I-7 | `s in [0.70, 0.77]` |
| 12 | I-8 | `s in [0.77, 0.805]` |
| 13 | I-9 | `s in [0.805, 0.825]` |
| 14 | I-10 | `s in [0.825, 0.84]` |
| 15 | II-propagated | `s in [2361/12500, 0.19]` |
| 16 | III-1 | `rho in [0.982, 0.984]` |
| 17 | III-2 | `rho in [0.984, 0.9846]` |
| 18 | III-3 | `rho in [0.9846, 0.9849]` |
| 19 | III-4 | `rho in [0.9849, 0.985]` |
| 20 | IV-1 | `rho in [0.985, 0.9855]` |

The gate is a **one-variable rational check** rather than a separate C++ region. With the paper's half-order normalization `k = 2c/d` and `kappa = mu(1 + sqrt(1+s))^2`, a sufficient exact condition over a band is

```text
(1 - max(phi,1-phi)/eta)^2 > 4 * s_max^2 * mu / (d^2 * eta),
```

with a positive unsquared left factor, where `s_max` is the upper endpoint. This is an analytic/rational verification obligation and **not an additional pair receipt**.

**Recorded output in the supplied ZIP:**

- [`theorem1/results/pair_certification_ledger.json`](theorem1/results/pair_certification_ledger.json) reports **60/60** certified C++ regions; the actual archived region records are `theorem1/results/pairs/pair_{01..20}_{left|right|cross}_receipt.json`. They include a result status and executable SHA-256 digest. The executable binaries themselves are not shipped.
- [`theorem1/results/profile_closure_ledger.json`](theorem1/results/profile_closure_ledger.json) and [`theorem1/results/profile_positive_base_ledger.json`](theorem1/results/profile_positive_base_ledger.json) report **20/20** completed rows for their respective checks. Individual files are `theorem1/results/half_row_##_closure.json` and `half_row_##_positive_base.json`.
- [`theorem1/results/supplementary_exact.json`](theorem1/results/supplementary_exact.json) records the extra Family-II/III/IV derivative bounds, Family-IV profile factor and `Lambda_IV` lower bound.
- [`theorem1/pair_build_manifest.json`](theorem1/pair_build_manifest.json) describes **generated/compiled candidates**, not completion; use the **pair certification ledger and receipts** for completion evidence.

## 4. Appendix C: Theorem 2 at alpha = 13/25

The computation covers the five crossover-probability bands in (27), **not** all exponents separately. The full interval `13/25 <= alpha < 1` follows in the manuscript from the **analytic Lemma 3** after establishing the endpoint exponent.

| Paper band | Code band name | `p` interval | Candidate input |
|---|---|---|---|
| `I_1` | `low` | `[1e-6, 1/50000]` | `theorem2/alpha_direct/closure/theorem2/candidate_theorem2_low.json` |
| `I_2` | `midlow` | `[1/50000, 1/2500]` | `.../candidate_theorem2_midlow.json` |
| `I_3` | `middle` | `[1/2500, 13/10000]` | `.../candidate_theorem2_middle.json` |
| `I_4` | `midhigh` | `[13/10000, 7/2000]` | `.../candidate_theorem2_midhigh.json` |
| `I_5` | `high` | `[7/2000, 29/4000]` | `.../candidate_theorem2_high.json` |

| Paper reference | Program | Precisely what is certified / NOT certified |
|---|---|---|
| **C.1**, kernel data (77), Tables 2–5; positivity of ten `N_i`, `P_i` polynomials on `[0, 79/200]` | `theorem2/alpha_direct/certification_generic/generate_and_build.py`, especially `polynomial_certificate()` | Exact rational Bernstein positivity of five `N_i` and five `P_i`. Generation also binds input hashes and prepares C++ headers. Endpoint identities and symmetry are algebraic, not standalone numerical checks. Archived summary: `theorem2/certificates/polynomial_positivity.json`. |
| **C.2**, pair inequality (12), rational-power endpoint factorizations (78)–(81) and left/right/cross regions | `theorem2/alpha_direct/certification_generic/verify_generic_hg.cpp`, generated `*.hpp`, and `theorem2/verify_nontrivial.py` | **15 full-domain C++ pair proofs**, three charts per band, with outward binary80 intervals and exact integer root bound checks. A passing fresh run must produce 15 completed region outputs and `theorem2/results/pairs/<timestamp>/summary.json`. Merely compiling or generating headers does **not** certify any region. |
| **C.2**, kernel concavity | Same C++ pair charts | Deduced from their **strictly positive diagonal limits** and the kernel-positivity premise; no independent concavity sampling is accepted. |
| **C.3**, closure (13) and the positive `J = 1-2cC/d` condition (82) | `theorem2/alpha_direct/closure/theorem2/certify_rational_alpha_aux.py` | Exact rational two-variable Bernstein checks across the five mean/influence regions, with complete noise-band bounds. The JSON includes strict lower bounds; the recorded values also exceed the manuscript's `J > 0.79` threshold. |
| **C.3**, three-bit base (14) | Same `certify_rational_alpha_aux.py`, using `theorem2/alpha_direct/closure/rational_aux_core.py` | Checks the **15 nontrivial increasing three-bit functions for each band**, via exact directed integer roots and noise-band subdivision. Constants and dictators are algebraic equalities. |
| **C.3**, gate (15), inequality (82) | Exact band parameters in the candidate JSON files; elementary scalar bound in the paper | No independent full-dimensional gate checker is run; the gate is a scalar parameter comparison. Do not describe a positive closure or `J` residual as *itself* a separate gate certificate. |
| **C.4**, Hellinger-tail (28) with `p_0 = 10^-6` | `theorem2/alpha_direct/closure/theorem2/certify_rational_hellinger.py` | **Only** the exact positive scalar supporting-line gap. It does **not** prove external **Theorem 3**, the analytic one-inflection/minorant **Lemma 4**, or a C++ pair inequality. Output: `theorem2/results/theorem2_hellinger_certificate.json`. |

**Status and provenance of Theorem 2 pair certificates:**

- Five `candidate_theorem2_*_aux_certificate.json` records are available in `theorem2/results/` and `theorem2/certificates/`; their declared status is `CERTIFIED: closure, J positivity and nontrivial three-bit bases`.
- `theorem2/certificates/historical_pair_manifest_20261024.json` reports **15/15 completed pair regions** and **370,716 accepted leaves** from a **historical run**. It is explicitly labeled *historical* and includes SHA-256 references to earlier records; those earlier individual full-domain outputs/checkpoint chains are **not supplied in this ZIP**. Do not present this summary as a new full rerun.
- `theorem2/alpha_direct/certification_generic/build_manifest_hg.json` identifies generated/compiled sources but explicitly says **no full-domain certification was run** as part of that build. The current ZIP does **not** contain `theorem2/results/pairs/<timestamp>/summary.json` or its 15 individual new-region outputs.
- For an **independent new result**, run the full `theorem2-pairs` target, retain **all 15** new region outputs and `summary.json`, and check successful termination. An interrupted region, partial checkpoint or old digest is insufficient.

## 5. Run instructions

From the **root directory extracted from this ZIP**:

```sh
# Requirements: Python >= 3.10, SymPy >= 1.11, and g++/a compatible C++17 compiler.
python3 -m pip install -r requirements.txt

# Theorem 1: Appendix-A scalar checks + profiles/closure/three-bit bases.
python3 verify_all.py theorem1-aux --jobs 3

# Theorem 1: regenerate/compile and rerun all 60 C++ pair regions.
python3 verify_all.py theorem1-pairs --jobs 3

# Theorem 2: exact auxiliary and Hellinger-tail checks, without pair regions.
python3 verify_all.py theorem2-aux

# Theorem 2: auxiliary checks, compile, and ALL 15 full-domain C++ pair regions.
python3 verify_all.py theorem2-pairs --jobs 3

# All of the above; potentially CPU-intensive.
python3 verify_all.py all --jobs 3
```

**Numerical rigor requirements:** Do **not** use `python -O` because assertion guards are used. The C++ pair engines require the specified x87 **binary80 `long double`** representation (`LDBL_MANT_DIG == 64`) and reject unsupported arithmetic environments. The runners require rigorous positive interval/Bernstein lower bounds; an unresolved cell, limit hit, runtime failure, or checkpoint **must not** be treated as a valid certificate. Theorem 2's fresh pair runner uses a maximum of **10,000,000** boxes per chart before failing. A full fresh run can be expensive; no timing guarantee is made.

### Reuse is not a fresh proof

`python3 verify_all.py all --jobs 3 --reuse-exact-receipts` may **skip already certified Theorem-1 calculations** subject to existing receipt/hash checks. Theorem 2 pair runner has **no analogous shortcut** in this wrapper. For an independent audit or a journal submission, prefer fresh full-domain runs and preserve the machine/compiler configuration, stdout/stderr, manifests, and complete successful receipts.

### File-integrity check (not a mathematical check)

```sh
python3 verify_package_integrity.py
```

This checks listed file bytes against `SOURCE_SHA256.json`; it does **not** evaluate any mathematical inequality. The **original uploaded `codes.zip`** had a **stale manifest**: it referred to four absent files (`RENAMING_VALIDATION.md`, `STATUS_AND_LIMITATIONS.md`, `appendix_repro_replacement.tex`, `manuscript_snapshot.tex`) and contained an outdated `README.md` hash. In the **repackaged ZIP distributed with this new README**, `SOURCE_SHA256.original_from_upload.json` preserves that original manifest for audit, and `SOURCE_SHA256.json` is regenerated against the files actually shipped. This repairs only *package integrity*, not missing historical proof material.

## 6. What is intentionally not a numerical proof obligation

- The union/overlap of explicit rational parameter bands and elementary chart-coverage comparisons.
- Symbolic identities for the kernel reflections, endpoint factorizations, fixed profile normalization, and constant/dictator base equalities.
- The analytic dimension induction **Proposition 1**, **Corollary 1**, **Lemmas 1, 3, 4, 5, 10, 12**, and the Fourier/semigroup manipulations beyond their finite scalar certificates.
- **Theorem 3**, the Hellinger contraction result: an *external cited theorem*, not a consequence of this software.
- The standalone **local dictator estimate (3)** in the Introduction: **no local theorem verification files are present** in the supplied archive.

## 7. Checklist for reviewers and maintainers

1. Check that the version of the PDF, the exact coefficient vectors in `theorem1/theorem1_rows.json`, and the five candidate JSON files agree. **The code's original extracted-data provenance refers to an earlier manuscript date; this README is mapped to the 26 October 2026 PDF.** Do not assume the SHA-256 of an older TeX snapshot equals that of the supplied PDF.
2. Verify all six Appendix-A exact tests and their connection to Lemmas 6–9 and 11; read the analytic proofs of Lemmas 5, 10, and 12 independently.
3. For Theorem 1, check 20/20 profile/closure/base results and **60/60** successful left/right/cross C++ pair receipts, not just `pair_build_manifest.json`.
4. For Theorem 2, check the five auxiliary candidates and ten `N/P` positivity certificates; then perform or obtain **all fifteen complete pair-region certificates**, not just `historical_pair_manifest_20261024.json`.
5. Independently check the elementary gate estimates and analytic continuation for Family II; check that each proof covers its **entire interval**, not only sampled points.
6. Treat the high-correlation Hellinger-tail JSON as a **scalar** check only. Verify the paper's Lemmas 3–4 and the externally cited Theorem 3 separately.
7. If retaining the Introduction's local bound (3), supply a separate valid proof and any required verification code; the present package does not cover it.

**Interpretation of `CERTIFIED`:** The status denotes a finite computation successfully completed **in its recorded environment**. It is neither a substitute for auditing the source code and proofs nor evidence that the calculation was independently re-executed while preparing this README.

#!/usr/bin/env python3
"""Byte-integrity check only; not a mathematical proof or numerical certificate."""
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'SOURCE_SHA256.json').read_text())
missing=[];changed=[]
for rel,expected in manifest['files'].items():
    path=ROOT/rel
    if not path.is_file():missing.append(rel);continue
    if hashlib.sha256(path.read_bytes()).hexdigest()!=expected:changed.append(rel)
if missing or changed:
    print('INTEGRITY FAILURE','missing:',missing,'changed:',changed)
    sys.exit(1)
print('SOURCE INTEGRITY PASS:',len(manifest['files']),'files')

#!/usr/bin/env python3
"""Recompute genuine alpha=13/25 inequality certificates (no trivial checks)."""
import argparse, hashlib, json, subprocess, sys, datetime
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed

ROOT=Path(__file__).resolve().parent
DIRECT=ROOT/'alpha_direct'
BANDS=('low','midlow','middle','midhigh','high')
REGIONS=('left','right','cross')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def call(relative,*args):
    subprocess.run([sys.executable,str(DIRECT/relative),*map(str,args)],check=True,cwd=ROOT)

def run_region(binary, band, region, folder):
    output=folder/(band+'_'+region+'.json')
    log=folder/(band+'_'+region+'.log')
    checkpoint=folder/(band+'_'+region+'_checkpoint.json')
    with output.open('w') as stdout,log.open('w') as stderr:
        result=subprocess.run([str(binary),region,'10000000',str(checkpoint)],
                              cwd=folder,stdout=stdout,stderr=stderr)
    if result.returncode:
        raise RuntimeError(f'UNRESOLVED/non-positive pair region: {band} {region}; see {checkpoint}')
    data=json.loads(output.read_text())
    if data.get('status')!='CERTIFIED: all boxes strictly positive' or data.get('resumed'):
        raise RuntimeError(f'No full-domain certificate: {band} {region}')
    return {'band':band,'chart':region,'certificate':str(output.relative_to(ROOT)),
            'sha256':sha(output),'accepted_leaves':data['accepted']}

def main():
    if not __debug__:
        raise RuntimeError('Do not disable Python assertions: interval routines use them.')
    ap=argparse.ArgumentParser()
    ap.add_argument('--aux-only',action='store_true',help='run all scalar, profile, base and polynomial tests')
    ap.add_argument('--jobs',type=int,default=3,help='parallel pair charts for full proof')
    ar=ap.parse_args()
    if ar.jobs<1: ap.error('--jobs must be positive')
    # Exact nontrivial 2D Bernstein closure, J positivity, and three-bit bases.
    for band in BANDS:
        candidate=DIRECT/'closure'/'theorem2'/f'candidate_theorem2_{band}.json'
        call('closure/theorem2/certify_rational_alpha_aux.py',candidate)
    # An exact root enclosure for the Hellinger supporting-line defect.
    call('closure/theorem2/certify_rational_hellinger.py','--alpha','13/25','--p','1/1000000')
    # Ten nontrivial N_i/P_i polynomial positivity checks on [0,79/200].
    flags=['--generate-only'] if ar.aux_only else []
    call('certification_generic/generate_and_build.py',*flags)
    if ar.aux_only:
        print('CERTIFIED: all nontrivial auxiliary certificates (not the pair regions)')
        return
    generic=DIRECT/'certification_generic'
    built=json.loads((generic/'build_manifest_hg.json').read_text())
    records={d['band']:d for d in built['bands']}
    # Provenance guards bind the exact rational parameters and compiled binary.
    for band in BANDS:
        record=records[band]
        candidate=DIRECT/'closure'/'theorem2'/f'candidate_theorem2_{band}.json'
        if sha(candidate)!=record['candidate_sha256']:
            raise RuntimeError('Candidate changed between auxiliary and pair proof')
        for name,want in record['dependency_sha256'].items():
            if sha(generic/name)!=want:
                raise RuntimeError('Compiled C++ source changed: '+name)
        if sha(generic/record['binary'])!=record['binary_sha256']:
            raise RuntimeError('Compiled binary changed: '+band)
    stamp=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    folder=ROOT/'results'/'pairs'/stamp
    folder.mkdir(parents=True,exist_ok=True)
    tasks=[(generic/records[b]['binary'],b,r,folder) for b in BANDS for r in REGIONS]
    results=[]
    with ThreadPoolExecutor(max_workers=ar.jobs) as pool:
        futures=[pool.submit(run_region,*args) for args in tasks]
        for future in as_completed(futures):
            row=future.result()
            results.append(row)
            print('CERTIFIED',row['band'],row['chart'],flush=True)
    if len(results)!=15:
        raise RuntimeError('Pair region not certified')
    report={'status':'CERTIFIED: all 15 pair domains and nontrivial auxiliary bounds',
            'alpha':'13/25','regions':sorted(results,key=lambda x:(x['band'],x['chart'])),
            'build_manifest_sha256':sha(generic/'build_manifest_hg.json'),
            'external_inputs':['Hellinger contraction','square-root comparison up to rho=0.9855']}
    (folder/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()

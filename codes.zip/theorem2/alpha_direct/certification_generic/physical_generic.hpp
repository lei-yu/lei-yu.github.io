#pragma once
#include "pairs_generic.hpp"

// An independent physical-t divided-difference expression. It is intended
// for a>=4/5,b>=1/2 in an endpoint chart: all t nodes then stay strictly
// inside (0,1), including both endpoints of every parameter box.
namespace certified {

template<class T>T physical_kernel(const T&t){
 T y=root(t,ALPHA_N),q=root(T(1)-t,ALPHA_N);
 T f=tighten_entropy_coordinate(y,q,power(y,ALPHA_M)+power(q,ALPHA_M)-T(1));
 T x=power(root(f,ALPHA_M),SHIFT);
 T nn=polynomial_value_guard(f,horner(Ncoeff(),f),true);
 T pp=polynomial_value_guard(f,horner(Pcoeff(),f),false);
 return f*(T(2)*t*pp+x*nn)/(pp+x*nn);
}

inline J physical_mixture_node(const J&u,const J&v,const J&p,const J&z){
 J result=meet(u+p*z,(J(1)-p)*u+p*v);
 // Since 0<=p<=1, the exact mixture belongs to the convex hull of the
 // endpoint ranges. This is a value enclosure only; derivatives retain
 // their independently computed enclosures.
 result.v=meet(result.v,I(std::min(u.v.lo,v.v.lo),std::max(u.v.hi,v.v.hi)));
 return result;
}

inline J physical_pair_unscaled(const J&u,const J&v,const J&z,const J&p){
 if(!(p.v.lo>0&&p.v.hi<1))throw std::runtime_error("physical pair p outside (0,1)");
 if(!(u.v.lo>0&&v.v.hi<1))throw std::runtime_error("physical pair nodes reach endpoints");
 J up=physical_mixture_node(u,v,p,z);
 J vp=physical_mixture_node(u,v,J(1)-p,z);
 DD rp=DD::variable({u,up,v}),rq=DD::variable({u,vp,v});
 DD gp=physical_kernel(rp),gq=physical_kernel(rq);
 J T0=-(J(1)-p)*(gp.e[6]+gq.e[6])/J(2);
 J S=J(phi())*gp.e[2]+J(I(1)-phi())*gp.e[0];
 J W0=J(1)-gp.e[4]/J(d0());
 // The result is the original pair residual divided by p*(v-u)^2,
 // continuously extended to coincident nodes.
 return T0*(S+J(eta())*p*power(z,2)*T0)
        -J(kappa())*entropy_sq_over_p(p)*power(W0,2);
}

inline J physical_right_pair(const J&a,const J&b,const J&p){
 J bn=power(b,ALPHA_N),an=power(a,ALPHA_N),z=bn*(J(1)-an);
 J u=J(1)-bn,v=J(1)-power(a*b,ALPHA_N);
 return power(b,2*SHIFT)*physical_pair_unscaled(u,v,z,p);
}

inline J physical_left_pair(const J&a,const J&b,const J&p){
 J bn=power(b,ALPHA_N),an=power(a,ALPHA_N),z=bn*(J(1)-an);
 J u=power(a*b,ALPHA_N),v=bn;
 return physical_pair_unscaled(u,v,z,p)/power(b,SHIFT);
}

inline bool physical_chart_applicable(const J&a,const J&b){
 return a.v.lo>=I::rat(4,5).hi&&b.v.lo>=I::rat(1,2).hi;
}

inline J right_pair_physical_tight(const J&a,const J&b,const J&p){
 J out=right_pair_tight(a,b,p);
 if(physical_chart_applicable(a,b)){
  try{return meet(out,physical_right_pair(a,b,p));}
  catch(const std::exception&){return out;}
 }
 return out;
}

inline J left_pair_physical_tight(const J&a,const J&b,const J&p){
 J out=left_pair_tight(a,b,p);
 if(physical_chart_applicable(a,b)){
  try{return meet(out,physical_left_pair(a,b,p));}
  catch(const std::exception&){return out;}
 }
 return out;
}
}

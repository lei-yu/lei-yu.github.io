#pragma once
// Generated from candidate_theorem2_high.json; terminating decimals are exact rationals.
namespace certified {
constexpr unsigned ALPHA_M=13, ALPHA_N=25;
constexpr const char* BAND_NAME="high";
constexpr const char* CANDIDATE_SHA256="27b9289c7b671fa39b19e732e2157f3c7c2d7f5bda02dda86afbf8fbd0a7152b";
constexpr const char* P_LOWER_RATIONAL="7/2000";
constexpr const char* P_UPPER_RATIONAL="29/4000";
inline const std::vector<I>& Ncoeff(){static const std::vector<I>v={I::rat(131213681LL,100000000LL),I::rat(110521627LL,100000000LL),I::rat(-366052671LL,100000000LL),I::rat(-1241294287LL,50000000LL),I::rat(168921249LL,12500000LL),I::rat(4095278517LL,100000000LL),I::rat(-3133530493LL,50000000LL)};return v;}
inline const std::vector<I>& Pcoeff(){static const std::vector<I>v={I::rat(1LL,1LL),I::rat(99079841LL,50000000LL),I::rat(-1079486261LL,100000000LL)};return v;}
inline I d0(){return Ncoeff()[0];}
inline I phi(){return I::rat(38704811LL,50000000LL);}
inline I eta(){return I::rat(60575399LL,50000000LL);}
inline I kappa(){return I::rat(15018LL,15625LL);}
inline I p_lower(){return I::rat(7LL,2000LL);}
inline I p_upper(){return I::rat(29LL,4000LL);}
inline I entropy_upper(){return I::rat(79LL,200LL);}
inline I N_global_lower(){return I::rat(13227787LL,100000000LL);}
inline I N_global_upper(){return I::rat(70979069LL,50000000LL);}
inline I P_global_lower(){return I::rat(984623LL,10000000LL);}
inline I P_global_upper(){return I::rat(69568269LL,50000000LL);}
}

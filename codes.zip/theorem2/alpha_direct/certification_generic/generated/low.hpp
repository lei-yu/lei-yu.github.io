#pragma once
// Generated from candidate_theorem2_low.json; terminating decimals are exact rationals.
namespace certified {
constexpr unsigned ALPHA_M=13, ALPHA_N=25;
constexpr const char* BAND_NAME="low";
constexpr const char* CANDIDATE_SHA256="ab17b5f377fa54c88c6f3e43ac924177691eb9eaab5c3ccf5859201cb688cd0f";
constexpr const char* P_LOWER_RATIONAL="1/1000000";
constexpr const char* P_UPPER_RATIONAL="1/50000";
inline const std::vector<I>& Ncoeff(){static const std::vector<I>v={I::rat(138358473LL,100000000LL),I::rat(275210049LL,100000000LL),I::rat(-31768361LL,5000000LL),I::rat(-2761650993LL,100000000LL),I::rat(208912501LL,50000000LL),I::rat(227945751LL,3125000LL),I::rat(-9922250911LL,100000000LL)};return v;}
inline const std::vector<I>& Pcoeff(){static const std::vector<I>v={I::rat(1LL,1LL),I::rat(347187799LL,100000000LL),I::rat(-1428876797LL,100000000LL)};return v;}
inline I d0(){return Ncoeff()[0];}
inline I phi(){return I::rat(4605827LL,5000000LL);}
inline I eta(){return I::rat(119559623LL,100000000LL);}
inline I kappa(){return I::rat(1010247LL,1000000LL);}
inline I p_lower(){return I::rat(1LL,1000000LL);}
inline I p_upper(){return I::rat(1LL,50000LL);}
inline I entropy_upper(){return I::rat(79LL,200LL);}
inline I N_global_lower(){return I::rat(10178801LL,50000000LL);}
inline I N_global_upper(){return I::rat(33597117LL,20000000LL);}
inline I P_global_lower(){return I::rat(7099339LL,50000000LL);}
inline I P_global_upper(){return I::rat(168569591LL,100000000LL);}
}

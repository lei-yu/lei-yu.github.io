#pragma once
// Generated from candidate_theorem2_middle.json; terminating decimals are exact rationals.
namespace certified {
constexpr unsigned ALPHA_M=13, ALPHA_N=25;
constexpr const char* BAND_NAME="middle";
constexpr const char* CANDIDATE_SHA256="9ddd1ed3eb134ac35ee294bae66ad89ce871c8e4aa51ac0cfeb846d913a4eebc";
constexpr const char* P_LOWER_RATIONAL="1/2500";
constexpr const char* P_UPPER_RATIONAL="13/10000";
inline const std::vector<I>& Ncoeff(){static const std::vector<I>v={I::rat(133201793LL,100000000LL),I::rat(244865333LL,50000000LL),I::rat(-37619651LL,10000000LL),I::rat(-4064239797LL,50000000LL),I::rat(17879212563LL,100000000LL),I::rat(-5332857147LL,25000000LL),I::rat(4480134067LL,50000000LL)};return v;}
inline const std::vector<I>& Pcoeff(){static const std::vector<I>v={I::rat(1LL,1LL),I::rat(564986921LL,100000000LL),I::rat(-481316691LL,25000000LL)};return v;}
inline I d0(){return Ncoeff()[0];}
inline I phi(){return I::rat(5217341LL,6250000LL);}
inline I eta(){return I::rat(57000981LL,50000000LL);}
inline I kappa(){return I::rat(23907LL,25000LL);}
inline I p_lower(){return I::rat(1LL,2500LL);}
inline I p_upper(){return I::rat(13LL,10000LL);}
inline I entropy_upper(){return I::rat(79LL,200LL);}
inline I N_global_lower(){return I::rat(15577317LL,50000000LL);}
inline I N_global_upper(){return I::rat(193769927LL,100000000LL);}
inline I P_global_lower(){return I::rat(11390043LL,50000000LL);}
inline I P_global_upper(){return I::rat(211584917LL,100000000LL);}
}

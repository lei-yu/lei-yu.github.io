#pragma once
// Generated from candidate_theorem2_midlow.json; terminating decimals are exact rationals.
namespace certified {
constexpr unsigned ALPHA_M=13, ALPHA_N=25;
constexpr const char* BAND_NAME="midlow";
constexpr const char* CANDIDATE_SHA256="4ae390fd4fe791a2da129ab03967b623676990eebd6f65078adea9e29fbe1518";
constexpr const char* P_LOWER_RATIONAL="1/50000";
constexpr const char* P_UPPER_RATIONAL="1/2500";
inline const std::vector<I>& Ncoeff(){static const std::vector<I>v={I::rat(26899221LL,20000000LL),I::rat(505044187LL,100000000LL),I::rat(-162520187LL,20000000LL),I::rat(-207216811LL,4000000LL),I::rat(7694145017LL,100000000LL),I::rat(-490664359LL,12500000LL),I::rat(-376102007LL,12500000LL)};return v;}
inline const std::vector<I>& Pcoeff(){static const std::vector<I>v={I::rat(1LL,1LL),I::rat(138744349LL,25000000LL),I::rat(-481316691LL,25000000LL)};return v;}
inline I d0(){return Ncoeff()[0];}
inline I phi(){return I::rat(5397247LL,6250000LL);}
inline I eta(){return I::rat(58468033LL,50000000LL);}
inline I kappa(){return I::rat(193477LL,200000LL);}
inline I p_lower(){return I::rat(1LL,50000LL);}
inline I p_upper(){return I::rat(1LL,2500LL);}
inline I entropy_upper(){return I::rat(79LL,200LL);}
inline I N_global_lower(){return I::rat(13032659LL,50000000LL);}
inline I N_global_upper(){return I::rat(24115211LL,12500000LL);}
inline I P_global_lower(){return I::rat(4706581LL,25000000LL);}
inline I P_global_upper(){return I::rat(52402009LL,25000000LL);}
}

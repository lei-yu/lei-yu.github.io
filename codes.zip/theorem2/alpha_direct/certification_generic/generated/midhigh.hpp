#pragma once
// Generated from candidate_theorem2_midhigh.json; terminating decimals are exact rationals.
namespace certified {
constexpr unsigned ALPHA_M=13, ALPHA_N=25;
constexpr const char* BAND_NAME="midhigh";
constexpr const char* CANDIDATE_SHA256="f13dbf392a7dda193685f35748ef472d4380eeb86cc26901e8cf2037a11f1896";
constexpr const char* P_LOWER_RATIONAL="13/10000";
constexpr const char* P_UPPER_RATIONAL="7/2000";
inline const std::vector<I>& Ncoeff(){static const std::vector<I>v={I::rat(4125153LL,3125000LL),I::rat(129490557LL,50000000LL),I::rat(107156821LL,100000000LL),I::rat(-8021298237LL,100000000LL),I::rat(18535209941LL,100000000LL),I::rat(-23279481503LL,100000000LL),I::rat(11061077433LL,100000000LL)};return v;}
inline const std::vector<I>& Pcoeff(){static const std::vector<I>v={I::rat(1LL,1LL),I::rat(371371121LL,100000000LL),I::rat(-291528749LL,20000000LL)};return v;}
inline I d0(){return Ncoeff()[0];}
inline I phi(){return I::rat(40064339LL,50000000LL);}
inline I eta(){return I::rat(60444341LL,50000000LL);}
inline I kappa(){return I::rat(119649LL,125000LL);}
inline I p_lower(){return I::rat(13LL,10000LL);}
inline I p_upper(){return I::rat(7LL,2000LL);}
inline I entropy_upper(){return I::rat(79LL,200LL);}
inline I N_global_lower(){return I::rat(13024601LL,50000000LL);}
inline I N_global_upper(){return I::rat(83609343LL,50000000LL);}
inline I P_global_lower(){return I::rat(19262727LL,100000000LL);}
inline I P_global_upper(){return I::rat(173345797LL,100000000LL);}
}

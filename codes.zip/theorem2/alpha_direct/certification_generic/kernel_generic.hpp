#pragma once
#include "interval_generic.hpp"
#ifndef COEFFICIENT_HEADER
#error "Pass -DCOEFFICIENT_HEADER=\"generated/<band>.hpp\""
#endif
#include COEFFICIENT_HEADER
#include "entropy_generic.hpp"
#include "polynomial_generic.hpp"

namespace certified {
constexpr unsigned SHIFT=ALPHA_N-ALPHA_M;
constexpr unsigned LEFT_POWER=2*ALPHA_N-ALPHA_M;
constexpr unsigned SMALL_POWER=2*ALPHA_M-ALPHA_N;
static_assert(2*ALPHA_M>ALPHA_N && ALPHA_M<ALPHA_N,"Require 1/2<alpha<1");
static_assert(ALPHA_M<=30 && ALPHA_N<=30,"Certified integer-root capacity");

inline const std::vector<I>& Ccoeff(){
 static const std::vector<I>v=[](){
  std::vector<I>v;
  const unsigned size=std::max(Ncoeff().size(),Pcoeff().size());
  for(unsigned j=1;j<size;++j)
   v.push_back(d0()*(j<Pcoeff().size()?Pcoeff()[j]:I(0))-(j<Ncoeff().size()?Ncoeff()[j]:I(0)));
  if(v.empty())v.push_back(I(0));
  return v;
 }();return v;
}

template<class T>std::array<T,3> endpoint(const T&y){
 T q=root(T(1)-power(y,ALPHA_N),ALPHA_N);
 T E=geometric_ratio_guard(q,geometric(q,ALPHA_M)/geometric(q,ALPHA_N));
 T B=T(1)-power(y,SHIFT)*E;
 T r=root(B,ALPHA_M),X=power(r,SHIFT),z=tighten_entropy_coordinate(y,q,power(y,ALPHA_M)*B);
 T nn=polynomial_value_guard(z,horner(Ncoeff(),z),true),pp=polynomial_value_guard(z,horner(Pcoeff(),z),false),den=pp+power(y,SHIFT)*X*nn;
 T A=(power(r,ALPHA_N)*nn+T(2)*power(y,ALPHA_M)*B*pp)/den;
 T M=(power(y,SMALL_POWER)*B*horner(Ccoeff(),z)
       +nn*E*geometric(r,ALPHA_N)/geometric(r,ALPHA_M)
       +T(d0())*X*nn-T(2)*power(y,SMALL_POWER)*B*pp)/den;
 T R=T(2)*B-power(y,SHIFT)*A;
 return {A,M,R};
}

template<class T>std::array<T,2> endpoint_ar(const T&y){
 T ys=power(y,SHIFT),ym=power(y,ALPHA_M),yn=power(y,ALPHA_N);
 T q=root(T(1)-yn,ALPHA_N);
 T E=geometric_ratio_guard(q,geometric(q,ALPHA_M)/geometric(q,ALPHA_N)),B=T(1)-ys*E;
 T r=root(B,ALPHA_M),X=power(r,SHIFT),z=tighten_entropy_coordinate(y,q,ym*B);
 T nn=polynomial_value_guard(z,horner(Ncoeff(),z),true),pp=polynomial_value_guard(z,horner(Pcoeff(),z),false),den=pp+ys*X*nn;
 T A=(power(r,ALPHA_N)*nn+T(2)*ym*B*pp)/den;
 T R=T(2)*B-ys*A;
 return {A,R};
}
template<class T>T right_R(const T&y){return endpoint_ar(y)[1];}
template<class T>T entropy_p(const T&p){
 return power(root(p,ALPHA_N),ALPHA_M)+power(root(T(1)-p,ALPHA_N),ALPHA_M)-T(1);
}
template<class T>T entropy_sq_over_p(const T&p){
 T yp=root(p,ALPHA_N),yq=root(T(1)-p,ALPHA_N);
 T B=T(1)-power(yp,SHIFT)*geometric(yq,ALPHA_M)/geometric(yq,ALPHA_N);
 return power(yp,SMALL_POWER)*power(B,2);
}
}

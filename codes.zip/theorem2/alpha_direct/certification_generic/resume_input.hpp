#pragma once
#include <map>
#include <sstream>
#include <cctype>
#include <climits>

// Included after Box is defined. This strict reader accepts only authenticated
// resume receipts produced by the migration runner, never a raw checkpoint.
namespace resume_io {
struct JSON {
 enum Type {OBJECT,ARRAY,STRING,INTEGER,BOOLEAN,NIL} type=NIL;
 std::map<std::string,JSON> object;std::vector<JSON> array;std::string text;
 std::uint64_t number=0;bool boolean=false;
 const JSON& at(const std::string&k)const{if(type!=OBJECT)throw std::runtime_error("JSON object required");return object.at(k);}
 std::string string()const{if(type!=STRING)throw std::runtime_error("JSON string required");return text;}
 std::uint64_t integer()const{if(type!=INTEGER)throw std::runtime_error("JSON integer required");return number;}
 bool truth()const{if(type!=BOOLEAN)throw std::runtime_error("JSON boolean required");return boolean;}
};
struct Parser {
 std::string s;std::size_t i=0;
 explicit Parser(std::string v):s(std::move(v)){}
 void ws(){while(i<s.size()&&std::isspace(static_cast<unsigned char>(s[i])))++i;}
 void need(char c){ws();if(i==s.size()||s[i++]!=c)throw std::runtime_error("invalid checkpoint JSON syntax");}
 std::string str(){need('"');std::string o;while(i<s.size()){
  char c=s[i++];if(c=='"')return o;
  if(c=='\\'){if(i==s.size())break;c=s[i++];if(c!='"'&&c!='\\'&&c!='/')throw std::runtime_error("unsupported JSON escape");}
  if(static_cast<unsigned char>(c)<32)throw std::runtime_error("JSON control character");o+=c;
 }throw std::runtime_error("unterminated JSON string");}
 JSON value(){ws();if(i==s.size())throw std::runtime_error("truncated JSON");JSON v;
  if(s[i]=='{'){v.type=JSON::OBJECT;++i;ws();if(i<s.size()&&s[i]=='}'){++i;return v;}
   while(true){std::string k=str();need(':');JSON x=value();if(!v.object.emplace(k,std::move(x)).second)throw std::runtime_error("duplicate JSON key");ws();if(i<s.size()&&s[i]=='}'){++i;return v;}need(',');}}
  if(s[i]=='['){v.type=JSON::ARRAY;++i;ws();if(i<s.size()&&s[i]==']'){++i;return v;}
   while(true){v.array.push_back(value());ws();if(i<s.size()&&s[i]==']'){++i;return v;}need(',');}}
  if(s[i]=='"'){v.type=JSON::STRING;v.text=str();return v;}
  if(s.compare(i,4,"true")==0){i+=4;v.type=JSON::BOOLEAN;v.boolean=true;return v;}
  if(s.compare(i,5,"false")==0){i+=5;v.type=JSON::BOOLEAN;return v;}
  if(s.compare(i,4,"null")==0){i+=4;return v;}
  if(std::isdigit(static_cast<unsigned char>(s[i]))){v.type=JSON::INTEGER;
   while(i<s.size()&&std::isdigit(static_cast<unsigned char>(s[i]))){unsigned d=s[i++]-'0';if(v.number>(UINT64_MAX-d)/10)throw std::runtime_error("JSON integer overflow");v.number=10*v.number+d;}return v;}
  throw std::runtime_error("unsupported JSON value");
 }
 JSON parse(){JSON v=value();ws();if(i!=s.size())throw std::runtime_error("trailing JSON data");return v;}
};

inline LD exact_hex(const std::string&s){
 std::size_t i=0;bool neg=false;if(i<s.size()&&(s[i]=='+'||s[i]=='-')){neg=s[i]=='-';++i;}
 if(s.compare(i,2,"0x")!=0)throw std::runtime_error("checkpoint endpoint must be hexadecimal");i+=2;
 std::uint64_t mant=0;unsigned fractional=0;bool dot=false,any=false;
 while(i<s.size()&&s[i]!='p'){
  char c=s[i++];if(c=='.'){if(dot)throw std::runtime_error("duplicate hex decimal point");dot=true;continue;}
  unsigned d=c>='0'&&c<='9'?c-'0':c>='a'&&c<='f'?c-'a'+10:99;
  if(d>15||mant>(UINT64_MAX-d)/16)throw std::runtime_error("hex significand exceeds exact 64-bit capacity");
  mant=16*mant+d;any=true;if(dot)++fractional;
 }
 if(!any||i==s.size()||s[i++]!='p')throw std::runtime_error("missing hex exponent");
 bool eneg=false;if(i<s.size()&&(s[i]=='+'||s[i]=='-')){eneg=s[i]=='-';++i;}
 int exponent=0;std::size_t begin=i;
 for(;i<s.size();++i){char c=s[i];if(c<'0'||c>'9'||exponent>100000)throw std::runtime_error("invalid hex exponent");exponent=10*exponent+c-'0';}
 if(i==begin)throw std::runtime_error("empty hex exponent");if(eneg)exponent=-exponent;
 exponent-=4*static_cast<int>(fractional);if(mant==0)return neg?-0.0L:0.0L;
 LD v=std::ldexp(static_cast<LD>(mant),exponent);
 if(!(v>0&&std::isfinite(v)))throw std::runtime_error("hex endpoint not representable");
 auto actual=dyadic(v);std::uint64_t wanted=mant;int e=exponent;
 while((wanted&1)==0){wanted>>=1;++e;}
 while((actual.mant&1)==0){actual.mant>>=1;++actual.exp;}
 if(wanted!=actual.mant||e!=actual.exp)throw std::runtime_error("hex endpoint would round");
 return neg?-v:v;
}

inline std::vector<Box> load(const std::string&path,const std::string&region,const Box&initial){
 std::ifstream f(path);if(!f)throw std::runtime_error("cannot open resume receipt");
 std::stringstream ss;ss<<f.rdbuf();JSON root=Parser(ss.str()).parse();
 auto require=[&](const std::string&k,const std::string&v){if(root.at(k).string()!=v)throw std::runtime_error("resume context mismatch: "+k);};
 require("format","rational-alpha-resume-v1");require("candidate_sha256",CANDIDATE_SHA256);
 require("band",BAND_NAME);require("region",region);require("residual_expression_version","normalized-pair-alpha-v1");
 require("p_lower_rational",P_LOWER_RATIONAL);require("p_upper_rational",P_UPPER_RATIONAL);
 require("endpoint_chart_bmax","99/100");require("cross_chart_max","19/20");
 if(!root.at("continuation_allowed").truth())throw std::runtime_error("continuation prohibited");
 const std::string status=root.at("predecessor_status").string();
 if(status!="INTERRUPTED: not a certificate"&&status!="UNRESOLVED: not a certificate")throw std::runtime_error("noncontinuable predecessor status");
 if(root.at("alpha_m").integer()!=ALPHA_M||root.at("alpha_n").integer()!=ALPHA_N)throw std::runtime_error("resume alpha mismatch");
 const JSON&boxes=root.at("boxes");if(boxes.type!=JSON::ARRAY||boxes.array.empty())throw std::runtime_error("empty/invalid resume box list");
 if(root.at("pending_count").integer()!=boxes.array.size())throw std::runtime_error("resume pending count mismatch");
 std::vector<Box>out;
 for(const auto&v:boxes.array){
  auto depth=v.at("depth").integer();if(depth>75)throw std::runtime_error("invalid checkpoint depth");
  const JSON&iv=v.at("intervals");if(iv.type!=JSON::ARRAY||iv.array.size()!=3)throw std::runtime_error("three intervals required");
  Box b; b.depth=static_cast<unsigned>(depth);
  for(unsigned j=0;j<3;++j){const JSON&pair=iv.array[j];if(pair.type!=JSON::ARRAY||pair.array.size()!=2)throw std::runtime_error("endpoint pair required");
   LD lo=exact_hex(pair.array[0].string()),hi=exact_hex(pair.array[1].string());
   if(!(initial.x[j].lo<=lo&&lo<hi&&hi<=initial.x[j].hi))throw std::runtime_error("resume box outside initial domain or degenerate");
   b.x[j]=I(lo,hi);
  }out.push_back(b);
 }
 return out;
}
}

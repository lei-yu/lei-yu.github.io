#!/usr/bin/env python3
"""Generate rational coefficient headers and compile independent band binaries.

No domain certificate is run by this script. Candidate decimals are parsed as
Decimal -> Fraction, never through a binary float. The source candidate SHA256
and generated-header SHA256 are recorded for each build.
"""
import argparse,json,hashlib,subprocess,math
from decimal import Decimal
from fractions import Fraction
from pathlib import Path

HERE=Path(__file__).resolve().parent
SEARCH=HERE.parent/'closure'/'theorem2'
BANDS=['low','midlow','middle','midhigh','high']


def cpp_rat(v):
    r=Fraction(v)
    if not -(2**63)<=r.numerator<2**63 or not 0<r.denominator<2**63:
        raise ValueError('Coefficient does not fit signed 64-bit rational arguments')
    return f'I::rat({r.numerator}LL,{r.denominator}LL)'


def polynomial_certificate(cfg):
    alpha=Fraction(cfg['alpha']);m,n=alpha.numerator,alpha.denominator
    # The elementary bound 2**(12/25)-1 < 79/200 is proved in README.
    R=Fraction(79,200)
    out=dict(status='Exact rational Bernstein bounds passed',entropy_upper=str(R),polynomials={})
    for key in ['N_F','P_F']:
        co=list(map(Fraction,cfg[key]));deg=len(co)-1
        for subdivisions in [1,2,4,8,16,32,64,128]:
            leaves=[]
            for i in range(subdivisions):
                a=R*i/subdivisions;h=R/subdivisions
                power_co=[sum(co[k]*math.comb(k,j)*a**(k-j)*h**j for k in range(j,deg+1)) for j in range(deg+1)]
                b=[sum(power_co[j]*Fraction(math.comb(k,j),math.comb(deg,j)) for j in range(k+1)) for k in range(deg+1)]
                leaves.append(b)
            minimum=min(min(v) for v in leaves);maximum=max(max(v) for v in leaves)
            if minimum>Fraction(1,10**8):break
        assert minimum>Fraction(1,10**8),(key,minimum)
        scale=10**8;low=Fraction((minimum*scale).__floor__(),scale);high=Fraction((maximum*scale).__ceil__(),scale)
        out['polynomials'][key]=dict(lower=str(low),upper=str(high),subdivisions=subdivisions,
            bernstein_coefficients=[[str(v) for v in leaf] for leaf in leaves])
    return out


def generate(band):
    source=SEARCH/f'candidate_theorem2_{band}.json'
    raw=source.read_bytes();cfg=json.loads(raw,parse_float=Decimal)
    alpha=Fraction(cfg['alpha']);m,n=alpha.numerator,alpha.denominator
    assert n//2<m<n<=30 and n<2*m
    polycert=polynomial_certificate(cfg)
    lines=['#pragma once','// Generated from '+source.name+'; terminating decimals are exact rationals.',
           'namespace certified {',f'constexpr unsigned ALPHA_M={m}, ALPHA_N={n};',
           f'constexpr const char* BAND_NAME="{band}";',
           f'constexpr const char* CANDIDATE_SHA256="{hashlib.sha256(raw).hexdigest()}";',
           f'constexpr const char* P_LOWER_RATIONAL="{Fraction(cfg["p_interval"][0])}";',
           f'constexpr const char* P_UPPER_RATIONAL="{Fraction(cfg["p_interval"][1])}";']
    for key,func in [('N_F','Ncoeff'),('P_F','Pcoeff')]:
        lines.append(f'inline const std::vector<I>& {func}(){{static const std::vector<I>v={{'+','.join(map(cpp_rat,cfg[key]))+'};return v;}')
    lines.append('inline I d0(){return Ncoeff()[0];}')
    for key in ['phi','eta','kappa']:
        lines.append(f'inline I {key}(){{return {cpp_rat(cfg[key])};}}')
    for key,v in zip(['p_lower','p_upper'],cfg['p_interval']):
        lines.append(f'inline I {key}(){{return {cpp_rat(v)};}}')
    lines.append(f'inline I entropy_upper(){{return {cpp_rat(polycert["entropy_upper"])};}}')
    for key,prefix in [('N_F','N'),('P_F','P')]:
        for end in ['lower','upper']:
            lines.append(f'inline I {prefix}_global_{end}(){{return {cpp_rat(polycert["polynomials"][key][end])};}}')
    lines.append('}')
    dest=HERE/'generated'/f'{band}.hpp';dest.write_text('\n'.join(lines)+'\n')
    return dict(band=band,candidate=str(source.relative_to(HERE.parent)),
        candidate_sha256=hashlib.sha256(raw).hexdigest(),header=str(dest.relative_to(HERE)),
        header_sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),m=m,n=n,
        p_interval=cfg['p_interval'],polynomial_range_certificate=polycert)


def main():
    pa=argparse.ArgumentParser();pa.add_argument('--bands',nargs='+',choices=BANDS,default=BANDS)
    pa.add_argument('--generate-only',action='store_true')
    pa.add_argument('--variant',choices=['hg'],default='hg');ar=pa.parse_args()
    (HERE/'generated').mkdir(exist_ok=True);(HERE/'bin').mkdir(exist_ok=True)
    records=[]
    for band in ar.bands:
        rec=generate(band)
        if not ar.generate_only:
            prefix='verify_hg_'
            binary=HERE/'bin'/f'{prefix}{band}'
            driver='verify_generic_hg.cpp'
            dependencies=[*HERE.glob('*.hpp'),HERE/driver,HERE/rec['header']]
            dependency_sha256={str(f.relative_to(HERE)):hashlib.sha256(f.read_bytes()).hexdigest() for f in dependencies}
            temporary=binary.with_name(binary.name+'.building')
            cmd=['g++','-std=c++17','-O2','-fno-fast-math','-ffp-contract=off',
                 '-DCOEFFICIENT_HEADER="generated/'+band+'.hpp"',str(HERE/driver),'-o',str(temporary)]
            subprocess.run(cmd,check=True)
            assert dependency_sha256=={str(f.relative_to(HERE)):hashlib.sha256(f.read_bytes()).hexdigest() for f in dependencies},'C++ source changed during compilation'
            temporary.chmod(0o755);temporary.replace(binary)
            rec['binary']=str(binary.relative_to(HERE));rec['compile_arguments']=[v.replace(str(HERE)+'/','') for v in cmd]
            rec['binary_sha256']=hashlib.sha256(binary.read_bytes()).hexdigest()
            rec['dependency_sha256']=dependency_sha256
            rec['info']=json.loads(subprocess.check_output([str(binary),'info'],text=True))
        records.append(rec);print('prepared',band,flush=True)
    out=dict(status='Generated/compiled generic framework only; no full-domain certification run',variant=ar.variant,bands=records)
    suffix='_hg'
    (HERE/f'build_manifest{suffix}.json').write_text(json.dumps(out,indent=2))


if __name__=='__main__':main()

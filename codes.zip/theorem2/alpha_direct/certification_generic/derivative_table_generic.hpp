#pragma once
#include "hermite_generic.hpp"
namespace certified {
inline constexpr const char* PHYSICAL_TABLE_KERNEL_SHA256=CANDIDATE_SHA256;
class PhysicalDerivativeTable {
 static constexpr unsigned BITS=13,N=1u<<BITS;
 std::array<std::vector<S3>,BITS+1> table;
public:
 PhysicalDerivativeTable(){
  table[0].resize(N);
  // The two cells meeting 0 or 1 are never queried. All requested hulls
  // lie within [.01,.99], so only interior derivative enclosures matter.
  for(unsigned k=1;k+1<N;++k){
   LD l=std::ldexp(static_cast<LD>(k),-static_cast<int>(BITS));
   LD h=std::ldexp(static_cast<LD>(k+1),-static_cast<int>(BITS));
   table[0][k]=physical_kernel_series(I(l,h));
  }
  for(unsigned j=1;j<=BITS;++j){unsigned len=1u<<j,half=len/2;table[j].resize(N-len+1);
   for(unsigned k=0;k+len<=N;++k)for(unsigned d=0;d<4;++d){I a=table[j-1][k].c[d],b=table[j-1][k+half].c[d];table[j][k].c[d]=I(std::min(a.lo,b.lo),std::max(a.hi,b.hi));}
  }
 }
 S3 range(I x)const{
  if(!(x.lo>=I::rat(1,100).hi&&x.hi<=I::rat(99,100).lo))throw std::runtime_error("derivative table hull outside [.01,.99]");
  // Multiplication by a power of two is exact here; rounding to the lower
  // integer selects a cell containing each boundary. An exact upper grid
  // boundary deliberately includes one extra cell, which is conservative.
  unsigned lo=static_cast<unsigned>(std::ldexp(x.lo,BITS));
  unsigned hi=static_cast<unsigned>(std::ldexp(x.hi,BITS));
  // Include two neighboring cells on each side, then explicitly verify
  // exact dyadic endpoint coverage. Index arithmetic cannot silently omit
  // a boundary cell, even if a platform ever changes the provisional cast.
  lo=lo>=2?lo-2:0;hi+=2;
  if(lo<1||hi+1>=N||lo>hi)throw std::runtime_error("derivative table indices invalid");
  LD covered_lo=std::ldexp(static_cast<LD>(lo),-static_cast<int>(BITS));
  LD covered_hi=std::ldexp(static_cast<LD>(hi+1),-static_cast<int>(BITS));
  if(!(covered_lo<=x.lo&&covered_hi>=x.hi))throw std::runtime_error("derivative table coverage check failed");
  unsigned len=hi-lo+1,j=31-__builtin_clz(len),width=1u<<j;S3 out;
  for(unsigned d=0;d<4;++d){I a=table[j][lo].c[d],b=table[j][hi-width+1].c[d];out.c[d]=I(std::min(a.lo,b.lo),std::max(a.hi,b.hi));}
  return out;
 }
};
inline S3 physical_kernel_tabulated_range(I x){static const PhysicalDerivativeTable table;return table.range(x);}
}

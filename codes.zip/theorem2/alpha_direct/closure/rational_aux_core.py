#!/usr/bin/env python3
"""Shared exact rational arithmetic for the alpha=13/25 auxiliary verifier.

This module contains only exponent-independent integer interval operations and
three-bit base enumeration. The caller installs the particular candidate's
entropy function, asymmetric kernel, and base profile before using the base
certificate; it deliberately makes no standalone mathematical claim.
"""
import sys
from pathlib import Path
from fractions import Fraction as Q
from fixed_point_intervals import I, SCALE, sqrt_fraction

PARAM = {}
F = None
G = None
source_data = None

def ii(x):
    x=Q(x);return I.rational(x.numerator,x.denominator)

def nthroot(n,k):
    assert n>=0 and k>0
    if n<2:return n
    x=1<<((n.bit_length()+k-1)//k)
    while True:
        y=((k-1)*x+n//x**(k-1))//k
        if y>=x:break
        x=y
    while (x+1)**k<=n:x+=1
    while x**k>n:x-=1
    return x

def power(x,n,d):
    assert x.lo>=0 and 0<n<d
    a=x.lo**n*SCALE**(d-n);b=x.hi**n*SCALE**(d-n)
    lo=nthroot(a,d);hi=nthroot(b,d)
    if hi**d<b:hi+=1
    return I(lo,hi)

def horner(co,x):
    v=ii(co[-1])
    for a in reversed(co[:-1]):v=v*x+ii(a)
    return v

def pa(a,b):
    out=dict(a)
    for k,v in b.items():out[k]=out.get(k,Q(0))+v
    return {k:v for k,v in out.items() if v}
def ps(a,c):return {k:v*c for k,v in a.items() if v*c}
def pm(a,b):
    out={}
    for (i,j),v in a.items():
        for (k,l),w in b.items():out[i+k,j+l]=out.get((i+k,j+l),Q(0))+v*w
    return out

def split_line(row):
    lines=[row]
    while len(lines[-1])>1:lines.append([(a+b)/2 for a,b in zip(lines[-1][:-1],lines[-1][1:])])
    return [r[0] for r in lines],[r[-1] for r in reversed(lines)]

def split_bern(a,axis):
    if axis==0:
        cols=[split_line(list(col)) for col in zip(*a)]
        return [list(z) for z in zip(*(v[0] for v in cols))],[list(z) for z in zip(*(v[1] for v in cols))]
    rows=[split_line(row) for row in a]
    return [v[0] for v in rows],[v[1] for v in rows]

def base_certificate():
    if F is None or G is None or source_data is None:
        raise RuntimeError("Candidate entropy, kernel, and source data must be installed first")
    sources,polys=source_data();lo=Q(PARAM['p_lo']);hi=Q(PARAM['p_hi'])
    stack=[(lo,hi,0)];leaves=0;depthmax=0;minraw=None
    while stack:
        lo,hi,depth=stack.pop();p=I(ii(lo).lo,ii(hi).hi)
        try:
            values={}
            for co in polys:
                t=horner(co,p);t=I(max(0,t.lo),min(SCALE,t.hi))
                values[co]=G(t)
            c=F(p);gaps=[]
            for mask,terms,B in sources:
                gap=sum((values[t] for t in terms),ii(0))/8-c*ii(B)
                gaps.append(gap.lo)
            okay=min(gaps)>0
        except (ArithmeticError,AssertionError):okay=False
        if okay:
            leaves+=1;depthmax=max(depthmax,depth)
            minraw=min(gaps) if minraw is None else min(minraw,min(gaps))
        else:
            assert depth<20,('base subdivision failed',lo,hi)
            mid=(lo+hi)/2;stack.extend([(lo,mid,depth+1),(mid,hi,depth+1)])
    return {'nontrivial_sources':len(sources),'unique_noisy_polynomials':len(polys),
            'slabs':leaves,'maxdepth':depthmax,'raw_gap_lower_fraction':str(Q(minraw,SCALE)),
            'constants_and_dictators':'symbolic identities'}


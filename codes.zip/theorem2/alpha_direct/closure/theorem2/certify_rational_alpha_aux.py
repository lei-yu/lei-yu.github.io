#!/usr/bin/env python3
"""Exact Bernstein closure/J positivity and fifteen nontrivial three-bit bases.

Algebraic normalizations, band adjacency, and the scalar gate are proved
directly in the paper notes and are deliberately not numerically tested.
"""
import json,hashlib,sys,argparse
from pathlib import Path
from fractions import Fraction as Q
from math import comb
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
import rational_aux_core as C
from rational_aux_core import I,SCALE,ii,power,horner,pa,ps,pm

ap=argparse.ArgumentParser()
ap.add_argument('candidate',help='locked candidate JSON')
ARGS=ap.parse_args()
LOCK=Path(ARGS.candidate).resolve()
DATA=json.loads(LOCK.read_text(),parse_float=str)
ALPHA=Q(DATA['alpha']);GAMMA=(1-ALPHA)/ALPHA
assert Q(1,2)<ALPHA<1
PLO,PHI=map(Q,DATA['p_interval'])
assert 0<PLO<=PHI<Q(1,2)
C.PARAM.update({'alpha':DATA['alpha'],'p_lo':DATA['p_interval'][0],
                'p_hi':DATA['p_interval'][1],'N':DATA['N_F'],'P':DATA['P_F'],
                'phi':DATA['phi'],'eta':DATA['eta'],'kappa':DATA['kappa']})
BC={}
for j,c in enumerate(DATA['B_coeff']):
    BC[j]=BC.get(j,Q(0))+Q(c);BC[j+2]=BC.get(j+2,Q(0))-Q(c)
BC={n:c for n,c in BC.items() if c}

def F(t):
    if t.lo==t.hi==0 or t.lo==t.hi==SCALE:return ii(0)
    r=I(min(t.lo,SCALE-t.hi),min(t.hi,SCALE-t.lo,SCALE//2))
    if t.lo<=SCALE//2<=t.hi:r=I(min(t.lo,SCALE-t.hi),SCALE//2)
    f=power(r,ALPHA.numerator,ALPHA.denominator)+power(1-r,ALPHA.numerator,ALPHA.denominator)-1
    return I(max(0,f.lo),f.hi)
C.F=F

def G(t):
    if t.lo==t.hi==0 or t.lo==t.hi==SCALE:return ii(0)
    f=F(t);xx=power(f,GAMMA.numerator,GAMMA.denominator)
    nn=horner(DATA['N_F'],f);pp=horner(DATA['P_F'],f)
    if nn.lo<=0 or pp.lo<=0:raise ArithmeticError('polynomial enclosure not positive')
    return f*(2*t*pp+xx*nn)/(pp+xx*nn)
C.G=G

def source_data():
    sources=[];allpolys=set()
    for mask in range(256):
        row=[(mask>>x)&1 for x in range(8)]
        if any(row[x]>row[x|(1<<j)] for x in range(8) for j in range(3)):continue
        polys=[]
        for x in range(8):
            counts=[sum(row[y] for y in range(8) if (x^y).bit_count()==j) for j in range(4)]
            co=[sum(counts[j]*comb(3-j,k-j)*(-1)**(k-j) for j in range(k+1)) for k in range(4)]
            polys.append(tuple(co))
        count=sum(row);mean=Q(count,4)-1
        dictator=count==4 and len(set(polys))==2 and set(polys)=={(0,1,0,0),(1,-1,0,0)}
        if count in [0,8] or dictator:continue
        profile=sum((c*mean**n for n,c in BC.items()),Q(0))
        sources.append((mask,polys,profile));allpolys.update(polys)
    return sources,sorted(allpolys)
C.source_data=source_data

PIECES=[(Q(-1),Q(-7,8),Q(1),Q(1)),
        (Q(-7,8),Q(-3,8),Q(9,16),Q(1,2)),
        (Q(-3,8),Q(3,8),Q(3,8),Q(0)),
        (Q(3,8),Q(7,8),Q(9,16),Q(-1,2)),
        (Q(7,8),Q(1),Q(1),Q(-1))]

def bernstein_piece(poly,piece):
    ml,mh,ba,bb=piece;co={}
    # m=ml+(mh-ml)u, x=(ba+bb*m)v.  Each piece maps the whole unit
    # square exactly onto the corresponding allowed mean/influence region.
    for (i,j),a in poly.items():
        for h in range(j+1):
            val=a*comb(j,h)*ba**(j-h)*bb**h
            for k in range(i+h+1):
                co[k,j]=co.get((k,j),Q(0))+val*comb(i+h,k)*ml**(i+h-k)*(mh-ml)**k
    co={k:v for k,v in co.items() if v}
    n=max(i for i,j in co);m=max(j for i,j in co)
    return [[sum((v*Q(comb(i,k),comb(n,k))*Q(comb(j,l),comb(m,l))
                  for (k,l),v in co.items() if k<=i and l<=j),Q(0))
             for j in range(m+1)] for i in range(n+1)]

def certify_piece(poly,piece):
    stack=[(bernstein_piece(poly,piece),0)];leaves=0;minimum=None;depthmax=0
    while stack:
        a,depth=stack.pop();mn=min(min(row) for row in a)
        if mn>0:
            leaves+=1;minimum=mn if minimum is None else min(minimum,mn);depthmax=max(depthmax,depth);continue
        assert depth<28,('uncertified polynomial box',depth,piece)
        left,right=C.split_bern(a,depth%2)
        stack.extend([(left,depth+1),(right,depth+1)])
    return {'leaves':leaves,'maxdepth':depthmax,'lower_bound_fraction':str(minimum)}

def profile_certificate():
    phi=Q(DATA['phi']);eta=Q(DATA['eta']);d=Q(DATA['d0']);kap=Q(DATA['kappa'])
    B={(n,0):v for n,v in BC.items()};A={};DD={}
    for n,v in BC.items():
        for j in range(1,n+1,2):DD[n-j,j-1]=DD.get((n-j,j-1),Q(0))+v*comb(n,j)
        for j in range(2,n+1,2):A[n-j,j-2]=A.get((n-j,j-2),Q(0))-v*comb(n,j)
    rhs=pm(A,pa(pa(B,ps(pm({(0,1):Q(1)},DD),2*phi-1)),ps(pm({(0,2):Q(1)},A),eta-1)))
    c0=F(ii(DATA['p_interval'][0]));c1=F(ii(DATA['p_interval'][1]))
    cmin=Q(c0.lo,SCALE);cmax=Q(c1.hi,SCALE)
    # With J>0, the closure expression is monotone in c, its direction
    # depending only on the sign of C.  It suffices to check both endpoints.
    jchecks=[];checks=[]
    for cv in [cmin,cmax]:
        J=pa({(0,0):Q(1)},ps(DD,-2*cv/d))
        diff=pa(ps(pm(J,J),kap),ps(rhs,-1))
        for piece in PIECES:
            jchecks.append(certify_piece(J,piece))
            checks.append(certify_piece(diff,piece))
    return {'closure':checks,'J_positive':jchecks,'c_interval_fractions':[str(cmin),str(cmax)]}

def main():
    prof=profile_certificate()
    print(LOCK.stem+': closure and J positivity certified',flush=True)
    base=C.base_certificate()
    print(LOCK.stem+': fifteen nontrivial three-bit bases certified',flush=True)
    bounds={'closure':str(min(Q(x['lower_bound_fraction']) for x in prof['closure'])),
            'J':str(min(Q(x['lower_bound_fraction']) for x in prof['J_positive'])),
            'nontrivial_base_raw_gap':base['raw_gap_lower_fraction']}
    if not all(Q(x)>0 for x in bounds.values()):
        raise ArithmeticError('A required nontrivial inequality was not certified')
    result={'status':'CERTIFIED: closure, J positivity and nontrivial three-bit bases',
            'candidate_sha256':hashlib.sha256(LOCK.read_bytes()).hexdigest(),
            'band':LOCK.stem,'profile':prof,'bases':base,
            'strict_lower_bounds':bounds}
    out=Path(__file__).resolve().parents[3]/'results'
    out.mkdir(exist_ok=True)
    outfile=out/(LOCK.stem+'_aux_certificate.json')
    outfile.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'closure_leaves':sum(x['leaves'] for x in prof['closure']),
                      'base_slabs':base['slabs'],'bounds':bounds}))

if __name__=='__main__':main()

#!/usr/bin/env python3
"""Exact scalar supporting-line check for rational alpha and rational p.

The default is alpha=13/25 and p=1/1000000.  This does not certify a
direct-kernel pair inequality or the external Boolean Hellinger theorem.
"""
import sys,json,argparse
from pathlib import Path
from fractions import Fraction as Q
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from rational_aux_core import ii,power,SCALE
from rational_aux_core import sqrt_fraction

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--alpha',default='13/25')
    ap.add_argument('--p',default='1/1000000');args=ap.parse_args()
    a=Q(args.alpha);p=Q(args.p);q=1-p;r=1-2*p
    assert Q(1,2)<a<1 and 0<p<Q(1,2)
    ss=4*p*q;s=sqrt_fraction(ss.numerator,ss.denominator)
    pa=power(ii(p),a.numerator,a.denominator)
    qa=power(ii(q),a.numerator,a.denominator)
    endpoint=power(ii(2),(1-a).numerator,(1-a).denominator)
    derivative=ii(a)*s/(2*ii(r))*(pa/ii(p)-qa/ii(q))
    gap=endpoint-pa-qa-(1-s)*derivative
    assert gap.lo>0
    # Outward decimal display endpoints are formed by integer floor/ceiling.
    rounded_lo=Q(gap.lo*10**12//SCALE,10**12)
    rounded_hi=Q((gap.hi*10**12+SCALE-1)//SCALE,10**12)
    result={'status':'exact scalar supporting-line gap only; Boolean use requires the external Hellinger theorem and the one-inflection lemma',
      'alpha_fraction':str(a),'p_endpoint_fraction':str(p),'rho_endpoint_fraction':str(r),
      's_squared_fraction':str(ss),'s_interval_integers':[s.lo,s.hi],
      'gap_interval_integers':[gap.lo,gap.hi],
      'fixed_point_denominator':str(SCALE),
      'rational_gap_enclosure':[str(rounded_lo),str(rounded_hi)],
      'gap_display_only':gap.display(),
      'pair_certified':False,'external_hellinger_independently_certified':False}
    out=Path(__file__).resolve().parents[3]/'results'
    out.mkdir(exist_ok=True)
    (out/'theorem2_hellinger_certificate.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
